# Input formats

Actual analysis data are not distributed in this repository. CSV files under `input_templates/` contain column headers only, with zero data rows. They are format templates, not executable model inputs.

Provide populated CSV files at the paths listed below before running models. Preserve the original column names. Use UTF-8 encoding and keep study/arm/effect identifiers as text, including any leading zeros.

## Shared conventions

- `outcome`: `PA` (physical activity), `SB` (total sedentary behaviour), `Screen` (screen time), `Sleep` (sleep duration).
- `TE`: analysis-scale contrast estimate. `seTE`: positive standard error. `variance`: sampling variance, consistent with `seTE^2`.
- Physical activity and total sedentary behaviour use SMD; screen time and sleep duration use MD in minutes/day.
- Effect directions are harmonised so positive values favour the intervention/treat1; for sedentary behaviour and screen time, positive values represent greater reductions.
- Node labels must match those used by the scripts, including the reference `Usual care/waitlist`. The pairwise files use comparator codes `UC/WL` and `ME`.
- Component columns are binary arm-level indicators. See the component-to-model definitions in `09_scripts/03_run_cnma.R`; do not treat the full matrix as one automatically identifiable model.
- Long covariance files use `block_id`, 1-based `row`/`column`, contrast identifiers and numeric `value`. Block labels must agree with the contrast IDs and ordering in the component-model input.
- Keep approved eligibility, analysis-status and sensitivity-group codes consistent with the explicit filters in the R scripts. Do not fill missing numeric values with zero.
- The original validation scripts check the frozen manuscript dataset (including fixed model/row counts). They are not generic validators for a newly substituted review dataset.

## Required files

### `01_inputs/R_long.csv`

Within-study heterogeneity covariance structure in long format.

Columns, in source order:

`block_id`, `row`, `column`, `row_contrast`, `column_contrast`, `value`

Used by: `09_scripts/03_run_cnma.R`.

### `01_inputs/S_primary_long.csv`

Exact within-study sampling covariance matrices in long format.

Columns, in source order:

`block_id`, `row`, `column`, `row_contrast`, `column_contrast`, `value`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`, `09_scripts/03_run_cnma.R`.

### `01_inputs/alternative_SD_registry_v1.csv`

Alternative-SD scenarios, provenance and availability flags.

Columns, in source order:

`effect_id`, `study_id`, `outcome`, `primary_sd`, `alternative_sd`, `candidate_order`, `alternative_role`, `donor_or_basis`, `unit`, `availability`, `source_record`, `source_locator`, `comparability_note`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`.

### `01_inputs/approved_arm_node_mapping_Gate6_locked.csv`

Approved arm-to-node mapping.

Columns, in source order:

`study_id`, `study_name`, `study_label`, `arm_id`, `original_arm_label`, `previous_node`, `approved_node`, `component_codes`, `evidence_summary`, `mapping_status`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`.

### `01_inputs/cnma_model_input_exact.csv`

Independent contrasts for component models with matching covariance block identifiers.

Columns, in source order:

`effect_id`, `study_id`, `outcome`, `treat1_arm_id`, `treat2_arm_id`, `TE`, `seTE`, `variance`, `covariance_block_id`

Used by: `09_scripts/03_run_cnma.R`.

### `01_inputs/component_arms_22.csv`

Arm-level binary component design matrix; the model-specific active subsets are defined in 03_run_cnma.R.

Columns, in source order:

`study_id`, `arm_id`, `T01`, `T02`, `T03`, `T04`, `T05`, `F01`, `F02`, `F03`, `F04`, `F05`, `F06`, `F07`, `F08`, `F09`, `I01`, `I02`, `I03`, `I04`, `I05`, `I06`, `I07`, `I08`

Used by: `09_scripts/03_run_cnma.R`.

### `01_inputs/effect_link.csv`

Effect-to-study, measurement, risk-of-bias and effect-modifier linkage.

Columns, in source order:

`effect_id`, `source_effect_row`, `study_id`, `study_name`, `outcome`, `outcome_code`, `outcome_measure`, `timepoint`, `timepoint_relation`, `comparison_id`, `treat1_node`, `treat2_node`, `direct_comparison`, `analysis_status`, `sensitivity_group`, `effect_measure`, `TE`, `seTE`, `variance`, `age_summary`, `age_mean_years`, `age_band`, `female_percent`, `setting_category`, `intervention_duration_summary`, `intervention_duration_weeks`, `rct_type`, `randomization_unit`, `measurement_type`, `measurement_tool`, `measurement_scope`, `measurement_evidence_status`, `rob_randomization`, `rob_recruitment_timing`, `rob_deviations`, `rob_missing_outcome`, `rob_measurement`, `rob_selection`, `rob_overall`, `rob_source_sheet`, `rob_link_status`, `source_md`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`, `09_scripts/13_run_pa_measurement_method_nmr.R`.

### `01_inputs/final_effect_rows.csv`

Effect extraction and derivation fields needed by sensitivity calculations.

Columns, in source order:

`study_id`, `study_name`, `outcome`, `outcome_measure`, `timepoint`, `comparison_id`, `intervention_arm`, `comparator_arm`, `effect_path`, `analysis_population`, `effect_measure`, `unit_original`, `n_intervention`, `n_comparator`, `mean_intervention`, `sd_intervention`, `mean_comparator`, `sd_comparator`, `reported_effect`, `reported_se`, `ci_level`, `ci_lower`, `ci_upper`, `sd_for_smd`, `sd_source`, `cluster_status`, `icc`, `clusters_intervention`, `clusters_comparator`, `direction`, `analysis_status`, `calculation_status`, `source_record`, `source_location`, `note`, `TE`, `seTE`, `variance`, `sensitivity_group`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`.

### `01_inputs/nma_all_rows.csv`

Contrast-level source pool for the prespecified sensitivity filters.

Columns, in source order:

`effect_id`, `source_effect_row`, `study_id`, `study_name`, `outcome`, `timepoint`, `comparison_id`, `treat1_arm_id`, `treat2_arm_id`, `treat1_node`, `treat2_node`, `effect_measure`, `analysis_unit`, `TE`, `seTE`, `variance`, `analysis_status`, `sensitivity_group`, `multi_arm_id`, `shared_control_arm_id`, `derived_comparison`, `sensitivity_scenario`, `mapping_status`, `package1`, `package2`, `cnma_arm_mapping`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`, `09_scripts/05_verify_numeric_results.R`.

### `01_inputs/nma_model_input_complete_multiarm_gate6.csv`

Complete contrast-level standard NMA input, including the multi-arm closure comparisons.

Columns, in source order:

`effect_id`, `source_effect_row`, `study_id`, `study_name`, `outcome`, `outcome_label`, `timepoint`, `comparison_id`, `treat1_arm_id`, `treat2_arm_id`, `treat1_node`, `treat2_node`, `effect_measure`, `analysis_unit`, `TE`, `seTE`, `variance`, `n_intervention`, `n_comparator`, `n_total_for_contrast`, `sensitivity_group`, `multi_arm_id`, `shared_control_arm_id`, `derived_comparison`, `mapping_status`, `analysis_status`, `direction`, `previous_treat1_node`, `previous_treat2_node`, `node_mapping_version`, `covariance_block_id`, `model_input_role`

Used by: `09_scripts/01_run_standard_nma.R`, `09_scripts/02_run_sensitivity_meta_regression.R`, `09_scripts/13_run_pa_measurement_method_nmr.R`.

### `01_inputs/nma_primary_gate6.csv`

Observed primary contrasts; used for reported network counts and sensitivity comparisons.

Columns, in source order:

`effect_id`, `source_effect_row`, `study_id`, `study_name`, `outcome`, `outcome_label`, `timepoint`, `comparison_id`, `treat1_arm_id`, `treat2_arm_id`, `treat1_node`, `treat2_node`, `effect_measure`, `analysis_unit`, `TE`, `seTE`, `variance`, `n_intervention`, `n_comparator`, `n_total_for_contrast`, `sensitivity_group`, `multi_arm_id`, `shared_control_arm_id`, `derived_comparison`, `mapping_status`, `analysis_status`, `direction`, `previous_treat1_node`, `previous_treat2_node`, `node_mapping_version`

Used by: `09_scripts/01_run_standard_nma.R`, `09_scripts/02_run_sensitivity_meta_regression.R`, `09_scripts/04_finalize_package.R`, `09_scripts/05_verify_numeric_results.R`.

### `01_inputs/rob_normalized.csv`

Outcome/result-level normalised risk-of-bias assessments.

Columns, in source order:

`study_id`, `outcome_code`, `rob_unique_id`, `rob_source_sheet`, `reference`, `experimental`, `comparator`, `result`, `aim`, `rob_randomization`, `rob_randomization_comment`, `rob_recruitment_timing`, `rob_recruitment_timing_comment`, `rob_deviations`, `rob_deviations_comment`, `rob_missing_outcome`, `rob_missing_outcome_comment`, `rob_measurement`, `rob_measurement_comment`, `rob_selection`, `rob_selection_comment`, `rob_overall`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`, `09_scripts/04_finalize_package.R`.

### `01_inputs/study_characteristics.csv`

Study-level characteristics and moderators.

Columns, in source order:

`study_id`, `study_name`, `country_region`, `rct_type`, `randomization_unit`, `setting_category`, `setting_detail`, `age_summary`, `age_mean_years`, `age_evidence_status`, `age_band`, `female_summary`, `female_percent`, `female_evidence_status`, `intervention_duration_summary`, `intervention_duration_weeks`, `duration_evidence_status`, `timepoint_relation`, `source_md`, `source_sections`, `study_sample_n_summary`, `study_sample_n_numeric`, `study_sample_n_unit`, `study_sample_n_basis`, `synthesis_n_summary`, `synthesis_n_numeric`, `synthesis_n_basis`, `n_evidence_status`, `n_source_locator`, `approved_nodes`, `approved_arm_node_mapping`, `node_mapping_status`

Used by: `09_scripts/02_run_sensitivity_meta_regression.R`.

### `pairwise/01_inputs/pairwise_model_input_READY_20260923.csv`

Model-ready study-level pairwise contrasts.

Columns, in source order:

`audit_id`, `study_id`, `author_year`, `study_name`, `outcome`, `comparator_type`, `active_node`, `effect_measure`, `analysis_unit`, `TE`, `seTE`, `ci_lower_95`, `ci_upper_95`, `direction`, `model_eligibility`, `combination_status`, `sensitivity_group`, `source_effect_id`, `source_anchor`, `review_note`

Used by: `pairwise/run_formal_pairwise_meta_analysis_20260923.R`.

### `pairwise/01_inputs/shared_control_GLS_sensitivity_20260923.csv`

Resolved shared-control covariance sensitivity scenarios.

Columns, in source order:

`audit_id`, `study_id`, `outcome`, `scenario_id`, `scenario`, `TE`, `seTE`, `ci_lower_95`, `ci_upper_95`, `min_eigenvalue`, `condition_number`, `gls_weights`

Used by: `pairwise/run_formal_pairwise_meta_analysis_20260923.R`.
