options(stringsAsFactors = FALSE, encoding = "UTF-8", warn = 1, digits = 15)
# Use the normal R library paths; optionally configure R_LIBS_USER before starting R.
suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(netmeta)
})

args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
analysis_root <- normalizePath(Sys.getenv("NMA_ANALYSIS_ROOT", unset = file.path(script_dir0, "..")), winslash = "/", mustWork = TRUE)
input_dir <- file.path(analysis_root, "01_inputs")
regression_dir <- file.path(analysis_root, "05_meta_regression")
reference_node <- "Usual care/waitlist"

read_input <- function(name) {
  read_csv(file.path(input_dir, name), col_types = cols(study_id = col_character()),
           locale = locale(encoding = "UTF-8"), show_col_types = FALSE)
}

write_csv8 <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  write_excel_csv(as.data.frame(x), path, na = "")
}

capture_warning <- function(expr) {
  warns <- character()
  value <- withCallingHandlers(expr, warning = function(w) {
    warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning")
  })
  list(value = value, warnings = unique(warns))
}

is_connected <- function(d) {
  nodes <- unique(c(d$treat1_node, d$treat2_node))
  if (!length(nodes)) return(FALSE)
  seen <- nodes[1]
  repeat {
    old <- seen
    for (i in seq_len(nrow(d))) {
      if (d$treat1_node[i] %in% seen || d$treat2_node[i] %in% seen)
        seen <- unique(c(seen, d$treat1_node[i], d$treat2_node[i]))
    }
    if (length(seen) == length(old)) break
  }
  setequal(seen, nodes)
}

fit_netmeta <- function(d, reference = reference_node) {
  if (!nrow(d) || !is_connected(d)) stop("PA network is empty or disconnected")
  capture_warning(netmeta(
    TE = TE, seTE = seTE, treat1 = treat1_node, treat2 = treat2_node,
    studlab = study_id, data = d, sm = unique(d$effect_measure)[1],
    common = FALSE, random = TRUE, prediction = TRUE,
    reference.group = reference, small.values = "bad", method.tau = "REML",
    details.chkmultiarm = TRUE, backtransf = FALSE, keepdata = TRUE
  ))
}

model_complete <- read_input("nma_model_input_complete_multiarm_gate6.csv")
links <- read_input("effect_link.csv")

node_codes <- c(
  "Usual care/waitlist" = "UCWL", "Minimal education" = "ME", "Health education" = "HE",
  "Behavioural intervention" = "BI", "Physical activity intervention" = "PAI",
  "Environmental intervention" = "ENV", "Physical activity + health education" = "PAHE",
  "Integrated multicomponent intervention" = "IMC"
)

method_by_study <- links %>%
  filter(outcome_code == "PA", analysis_status == "primary") %>%
  group_by(study_id) %>%
  summarise(
    measurement_types = paste(sort(unique(measurement_type)), collapse = ";"),
    measurement_method = ifelse(all(grepl("^objective", measurement_type)),
                                "objective_device", "report_diary_or_interview"),
    reported_method = as.integer(measurement_method == "report_diary_or_interview"),
    .groups = "drop"
  )

d <- model_complete %>%
  filter(outcome == "PA") %>%
  left_join(method_by_study, by = "study_id")

if (anyNA(d$reported_method)) stop("PA measurement-method mapping is incomplete")
if (n_distinct(d$study_id) != 31L) stop("Expected 31 PA studies")
study_counts <- d %>% distinct(study_id, measurement_method) %>% count(measurement_method)
if (!identical(sort(study_counts$n), c(6L, 25L))) stop("Expected 25 objective and 6 reported PA studies")

d$treat1_node_full <- d$treat1_node
d$treat2_node_full <- d$treat2_node
d$treat1_node <- unname(node_codes[d$treat1_node])
d$treat2_node <- unname(node_codes[d$treat2_node])
if (anyNA(d$treat1_node) || anyNA(d$treat2_node)) stop("Node abbreviation failed for PA")

base_run <- fit_netmeta(d, reference = "UCWL")
base <- base_run$value
cov_map <- setNames(d$reported_method[!duplicated(d$study_id)], d$study_id[!duplicated(d$study_id)])
covar_vector <- unname(cov_map[base$data$.studlab])
if (anyNA(covar_vector)) stop("Measurement-method mapping failed after netmeta preparation")

reg_run <- capture_warning(netmetareg(
  base, covar = covar_vector, consistency = TRUE,
  assumption = "common", method.tau = "REML"
))
reg <- reg_run$value
br <- reg$results[reg$results$type == "beta", , drop = FALSE]
if (nrow(br) != 1L) stop("Expected one common-interaction measurement-method coefficient")

dir.create(file.path(regression_dir, "models"), recursive = TRUE, showWarnings = FALSE)
saveRDS(
  list(
    base = base,
    regression = reg,
    input = d,
    coding = "reported_method=1; objective_device=0",
    scope = "exploratory study-level common-interaction network meta-regression"
  ),
  file.path(regression_dir, "models", "PA_measurement_method_NMR_REML.rds")
)

status <- data.frame(
  outcome = "PA",
  analysis_role = "exploratory_supplementary",
  model = "common_interaction_network_meta_regression",
  status = "SUCCESS",
  studies = n_distinct(d$study_id),
  objective_studies = sum(!duplicated(d$study_id) & d$reported_method == 0L),
  reported_studies = sum(!duplicated(d$study_id) & d$reported_method == 1L),
  rows = nrow(d),
  nodes = length(base$trts),
  baseline_tau2 = base$tau^2,
  residual_tau2 = reg$tau2,
  optimizer_convergence = ifelse(is.null(reg$opt.res$convergence), NA, reg$opt.res$convergence),
  warnings = paste(c(base_run$warnings, reg_run$warnings), collapse = " | "),
  stringsAsFactors = FALSE
)

coefficient <- data.frame(
  outcome = "PA",
  analysis_role = "exploratory_supplementary",
  covariate = "reported_diary_or_interview_vs_objective_device",
  reference_category = "objective_device",
  contrast_category = "report_diary_or_interview",
  interpretation_unit = "reported/diary/interview versus objective device",
  beta = br$coef,
  se = br$se,
  lower = br$lower,
  upper = br$upper,
  z = br$z,
  p_value = br$pval,
  baseline_tau2 = base$tau^2,
  residual_tau2 = reg$tau2,
  interpretation_scope = "Exploratory study-level association; common interaction; not causal",
  conclusion = "No statistical evidence that PA measurement method modifies the network treatment effect",
  stringsAsFactors = FALSE
)

input_audit <- d %>%
  select(outcome, study_id, effect_id, treat1_node, treat2_node,
         treat1_node_full, treat2_node_full, TE, seTE,
         measurement_types, measurement_method, reported_method)

write_csv8(status, file.path(regression_dir, "measurement_method_NMR_model_status.csv"))
write_csv8(coefficient, file.path(regression_dir, "measurement_method_NMR_coefficients.csv"))
write_csv8(input_audit, file.path(regression_dir, "measurement_method_NMR_input.csv"))

cat("PA_MEASUREMENT_METHOD_NMR_COMPLETE\n")
print(status)
print(coefficient)
