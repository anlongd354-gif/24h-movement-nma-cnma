args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
scripts <- c("01_run_standard_nma.R", "02_run_sensitivity_meta_regression.R", "03_run_cnma.R", "04_finalize_package.R")
for (s in scripts) {
  cat("RUNNING ", s, "\n", sep = "")
  status <- system2(file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript"), shQuote(file.path(script_dir, s)))
  if (!identical(status, 0L)) stop("Script failed: ", s, " (exit ", status, ")")
}
cat("ALL_V3_1_ANALYSES_COMPLETE\n")
