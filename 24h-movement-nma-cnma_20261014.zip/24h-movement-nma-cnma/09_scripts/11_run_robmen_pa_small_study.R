args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- dirname(chartr("\\", "/", file0[[1]]))
analysis_root <- normalizePath(Sys.getenv("NMA_ANALYSIS_ROOT", unset = file.path(script_dir0, "..")), winslash = "/", mustWork = TRUE)
input_dir <- file.path(analysis_root, "01_inputs")
standard_dir <- file.path(analysis_root, "03_standard_nma")
regression_dir <- file.path(analysis_root, "05_meta_regression")
cinema_dir <- file.path(analysis_root, "07_cinema_pending")

# Use the normal R library paths; optionally configure R_LIBS_USER before starting R.
suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(netmeta)
})

write_csv8 <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  write_excel_csv(as.data.frame(x), path, na = "")
}

duration_model <- readRDS(file.path(regression_dir, "models", "PA_duration_NMR_REML.rds"))
base <- duration_model$base
dd <- base$data

# ROB-MEN uses a study-level pooled sampling variance as the small-study
# covariate. For the locked IV network, use the mean multi-arm-adjusted sampling
# variance within each study and center it at the smallest observed value.
study_var <- tapply(dd$.seTE.adj.random^2, dd$.studlab, mean, na.rm = TRUE)
covar <- unname(study_var[as.character(dd$.studlab)])
covar_centered <- covar - min(covar)

common <- netmetareg(base, covar = covar_centered, consistency = TRUE,
                     assumption = "common", method.tau = "REML")
independent <- netmetareg(base, covar = covar_centered, consistency = TRUE,
                          assumption = "independent", method.tau = "REML")

coef_common <- common$results
coef_common$model <- "common_interaction"
coef_independent <- independent$results
coef_independent$model <- "independent_treatment_specific_interactions"
coefs <- bind_rows(coef_common, coef_independent) %>%
  mutate(covariate = "study_mean_multiarm_adjusted_sampling_variance_centered_at_minimum",
         interpretation = ifelse(type == "beta",
           "No clear small-study effect when CI includes zero; treatment-specific slopes are exploratory and may be unstable",
           "Estimated treatment effect at the smallest observed study variance"))
write_csv8(coefs, file.path(cinema_dir, "ROB_MEN_PA_small_study_coefficients_v1.csv"))

code_to_name <- c(
  BI = "Behavioural intervention", ENV = "Environmental intervention",
  HE = "Health education", IMC = "Integrated multicomponent intervention",
  ME = "Minimal education", PAHE = "Physical activity + health education",
  PAI = "Physical activity intervention"
)
primary <- read_csv(file.path(standard_dir, "effects", "network_effects_vs_UCWL.csv"),
                    show_col_types = FALSE) %>% filter(outcome == "PA")
at_min_common <- coef_common %>% filter(type == "d") %>%
  transmute(code = treat, common_NMR_TE_at_min_variance = coef,
            common_NMR_lower = lower, common_NMR_upper = upper)
at_min_ind <- coef_independent %>% filter(type == "d") %>%
  transmute(code = treat, independent_NMR_TE_at_min_variance = coef,
            independent_NMR_lower = lower, independent_NMR_upper = upper)
shift <- tibble(code = names(code_to_name), treatment = unname(code_to_name)) %>%
  left_join(primary %>% select(treatment, primary_TE = TE, primary_lower = lower,
                               primary_upper = upper), by = "treatment") %>%
  left_join(at_min_common, by = "code") %>%
  left_join(at_min_ind, by = "code") %>%
  mutate(common_shift = common_NMR_TE_at_min_variance - primary_TE,
         independent_shift = independent_NMR_TE_at_min_variance - primary_TE,
         common_direction_changed = sign(common_NMR_TE_at_min_variance) != sign(primary_TE),
         independent_direction_changed = sign(independent_NMR_TE_at_min_variance) != sign(primary_TE),
         note = "Exploratory ROB-MEN support; absence of statistical significance does not prove absence of reporting bias")
write_csv8(shift, file.path(cinema_dir, "ROB_MEN_PA_small_study_effect_shift_v1.csv"))

writeLines(c(
  paste0("R: ", R.version.string),
  paste0("netmeta: ", packageVersion("netmeta")),
  "model: frequentist contrast-based network meta-regression; REML",
  "covariate: study-level mean multi-arm-adjusted sampling variance, centered at minimum",
  "assumptions: common interaction and independent treatment-specific interactions",
  "role: exploratory support for ROB-MEN; not a substitute for missing-study search audit"
), file.path(cinema_dir, "ROB_MEN_PA_small_study_session_v1.txt"), useBytes = TRUE)

beta_common <- coef_common %>% filter(type == "beta")
cat("ROB_MEN_PA_SMALL_STUDY_COMPLETE\n")
print(beta_common)
print(shift %>% select(treatment, primary_TE, common_NMR_TE_at_min_variance,
                       independent_NMR_TE_at_min_variance,
                       common_direction_changed, independent_direction_changed))
