# Release verification

Release date: 14 October 2026.

## Checks completed

- All 11 R files passed R syntax parsing; all nine required analysis packages were available at the recorded versions.
- Public-file scope: no actual analysis inputs or results; 15 CSV templates each contain one header row and no data rows.
- No personal machine-specific absolute paths or credential-like strings were detected in the public files.
- The portable code copies were executed in an isolated local verification directory with the original matching analysis inputs. Original project scripts and inputs remained unchanged.
- Pairwise, standard NMA, sensitivity, duration meta-regression, component analyses and the two auxiliary PA analyses executed successfully.
- All 18 numerical/input checks passed with the documented release-only correction for the existing optional S07 branch.

## Numerical output comparison

Selected numerical CSV outputs were compared against the archived model outputs, with absolute and relative tolerances of 1e-8. No numerical result values or actual model input data are included in this code-only repository.

| Output file | Comparison |
| --- | --- |
| `03_standard_nma/effects/network_effects_vs_UCWL.csv` | PASS |
| `03_standard_nma/effects/network_effects_all_pairs.csv` | PASS |
| `03_standard_nma/effects/heterogeneity.csv` | PASS |
| `03_standard_nma/rankings/P_scores.csv` | PASS |
| `04_sensitivity/sensitivity_effects_vs_UCWL.csv` | PASS |
| `05_meta_regression/duration_NMR_coefficients.csv` | PASS |
| `06_cnma/coefficients/CNMA_component_coefficients.csv` | PASS |
| `pairwise/formal_model_run_20260923/pairwise_model_results.csv` | PASS |
| `pairwise/formal_model_run_20260923/pairwise_shared_control_sensitivity.csv` | PASS |
| `05_meta_regression/measurement_method_NMR_coefficients.csv` | PASS |

The existing optional `S07_INCLUDE_STUDY29_PA` branch executed successfully but has no archived numerical counterpart. It was excluded from the archived-output comparison; all matching archived sensitivity scenarios passed. The release verifier validates this branch against its input condition rather than treating a fixed count of 40 as universal.

## Scope

These checks validate the code release with the matching local inputs. Downloading this repository alone does not reproduce results: users must separately provide the actual input files. Header-only templates are not data.

The historical validation script checks the manuscript dataset. Its fixed sensitivity count was corrected in the release copy to allow the existing input-triggered optional S07 branch while retaining the 40 base scenarios, successful-fit and uniqueness checks. The analysis/model code was not changed. These review-specific checks are not generic tests for other datasets.

The checks cover model execution and the numerical CSV comparisons listed above. They do not validate manual CINeMA/ROB-MEN judgements, final manuscript layout or publication artwork.
