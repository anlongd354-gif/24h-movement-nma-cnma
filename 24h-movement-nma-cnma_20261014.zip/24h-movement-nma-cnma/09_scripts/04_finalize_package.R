args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
source(file.path(script_dir0, "00_common.R"), encoding = "UTF-8")

primary <- read_input("nma_primary_gate6.csv")
rob <- read_input("rob_normalized.csv")
main_status <- read_csv(file.path(standard_dir, "logs", "standard_NMA_model_status.csv"), show_col_types = FALSE)
main_effects <- read_csv(file.path(standard_dir, "effects", "network_effects_all_pairs.csv"), show_col_types = FALSE)
ref_effects <- read_csv(file.path(standard_dir, "effects", "network_effects_vs_UCWL.csv"), show_col_types = FALSE)
contrib <- read_csv(file.path(standard_dir, "inconsistency", "contribution_matrix_long.csv"), show_col_types = FALSE)
sens_status <- read_csv(file.path(sensitivity_dir, "sensitivity_model_status.csv"), show_col_types = FALSE)
reg_coef <- read_csv(file.path(regression_dir, "duration_NMR_coefficients.csv"), show_col_types = FALSE)
reg_status <- read_csv(file.path(regression_dir, "duration_NMR_model_status.csv"), show_col_types = FALSE)
cnma_status <- read_csv(file.path(cnma_dir, "CNMA_parent_model_registry.csv"), show_col_types = FALSE)
cnma_coef <- read_csv(file.path(cnma_dir, "coefficients", "CNMA_component_coefficients.csv"), show_col_types = FALSE)

for (o in outcomes) {
  d <- primary[primary$outcome == o, c("study_id", "effect_id", "treat1_node", "treat2_node", "TE", "seTE", "effect_measure", "analysis_unit"), drop = FALSE]
  names(d)[names(d) == "study_id"] <- "study"
  write_csv8(d, file.path(cinema_dir, paste0("CINeMA_upload_contrast_data_", o, ".csv")))
}

rob_map <- rob %>% mutate(outcome = recode(outcome_code, ST = "Screen", SD = "Sleep", .default = outcome_code)) %>%
  select(study_id, outcome, rob_overall, rob_source_sheet) %>% distinct()
rob_rows <- primary %>% left_join(rob_map, by = c("study_id", "outcome")) %>%
  mutate(direct_comparison = paste(pmin(treat1_node, treat2_node), pmax(treat1_node, treat2_node), sep = " vs "),
         rob_link_status = ifelse(is.na(rob_overall), "UNMATCHED", "MATCHED")) %>%
  select(outcome, study_id, effect_id, treat1_node, treat2_node, direct_comparison, rob_overall, rob_source_sheet, rob_link_status)
write_csv8(rob_rows, file.path(cinema_dir, "CINeMA_RoB2_result_level_input.csv"))
write_csv8(contrib, file.path(cinema_dir, "CINeMA_contribution_matrix_long.csv"))

equiv <- data.frame(
  outcome = outcomes, effect_scale = c("SMD", "SMD", "MD min/day", "MD min/day"),
  candidate_lower = c(-.20, -.20, -30, -30), candidate_upper = c(.20, .20, 30, 30),
  status = "PENDING_USER_AND_EXTERNAL_RATIONALE_ADJUDICATION",
  required_before_use = "Document source, population relevance, clinical interpretation and adjudication date; do not call a validated MCID",
  sensitivity_range = "At most one externally justified alternative range", stringsAsFactors = FALSE)
write_csv8(equiv, file.path(cinema_dir, "CINeMA_equivalence_ranges_PENDING.csv"))

cinema_template <- main_effects %>% transmute(
  outcome, comparison, treatment1, treatment2, TE, lower, upper,
  within_study_bias = "", reporting_bias = "", indirectness = "", imprecision = "",
  heterogeneity = "", incoherence = "", overall_confidence = "",
  reviewer_rationale = "", adjudication_status = "PENDING_MANUAL_CINEMA")
write_csv8(cinema_template, file.path(cinema_dir, "CINeMA_manual_adjudication_template.csv"))

robmen <- main_effects %>% transmute(
  outcome, comparison, missing_evidence_bias_judgment = "", small_study_effects_assessed = "",
  known_missing_results = "", rationale = "", status = "PENDING_ROB_MEN")
write_csv8(robmen, file.path(cinema_dir, "ROB_MEN_comparison_template.csv"))

writeLines(c(
  "# CINeMA and ROB-MEN pending work",
  "",
  "This directory contains contrast data, contribution matrices, result-level RoB 2 links, an equivalence-range registry, the six-domain manual template, and the ROB-MEN template.",
  "",
  "Formal certainty ratings have not been generated. Complete the external rationale and adjudication of equivalence ranges, the six CINeMA domains, and comparison-level ROB-MEN before assigning High, Moderate, Low, or Very low confidence.",
  "",
  "CINeMA applies to the eight-node standard NMA comparisons and not to cNMA component coefficients."
), file.path(cinema_dir, "README_CINeMA_PENDING.md"), useBytes = TRUE)

fmt <- function(x, n = 3) ifelse(is.na(x), "NA", formatC(x, digits = n, format = "f"))
main_lines <- c(
  "# v3.1 formal analysis run overview", "",
  "## Standard NMA", "",
  "| Outcome | Studies | Nodes | tau2 | I2 | Global inconsistency P |", "|---|---:|---:|---:|---:|---:|"
)
for (i in seq_len(nrow(main_status))) {
  z <- main_status[i, ]
  main_lines <- c(main_lines, paste0("| ", z$outcome_label, " | ", z$studies, " | ", z$nodes,
    " | ", fmt(z$tau2, 4), " | ", fmt(100 * z$I2, 1), "% | ", fmt(z$p_Q_inconsistency, 4), " |"))
}
main_lines <- c(main_lines, "", "Positive values favour intervention for all four outcomes. P-scores are descriptive.", "",
  "## Intervention-duration network meta-regression", "", "| Outcome | Studies | Coefficient per duration doubling | 95% CI | P value |", "|---|---:|---:|---:|---:|")
for (i in seq_len(nrow(reg_coef))) {
  z <- reg_coef[i, ]; rs <- reg_status[reg_status$outcome == z$outcome, ]
  main_lines <- c(main_lines, paste0("| ", outcome_labels[[z$outcome]], " | ", rs$studies, " | ", fmt(z$beta),
    " | ", fmt(z$lower), " to ", fmt(z$upper), " | ", fmt(z$p_value, 4), " |"))
}
main_lines <- c(main_lines, "", "This is a study-level association and not a causal dose-response. Study 17 is excluded only from this analysis because duration is not numeric.", "",
  "## cNMA status", "", "| Outcome | Model | Parameters/rank | Residual df | tau2 | Parent components | Additivity P | Status |", "|---|---|---:|---:|---:|---:|---:|---|")
for (i in seq_len(nrow(cnma_status))) {
  z <- cnma_status[i, ]
  main_lines <- c(main_lines, paste0("| ", outcome_labels[[z$outcome]], " | ", z$model, " | ", z$active_parameters, "/", z$active_rank,
    " | ", z$residual_df, " | ", fmt(z$tau2, 4), " | ", z$parent_connected_components,
    " | ", fmt(z$p_difference, 4), " | ", z$status, " |"))
}
main_lines <- c(main_lines, "", "Component coefficients depend on additivity, exchangeability, and the active design matrix.", "",
  "## Outstanding", "", "- External rationale and final adjudication of CINeMA equivalence ranges.", "- Manual six-domain CINeMA assessment.", "- Comparison-level ROB-MEN assessment.")
writeLines(main_lines, file.path(report_dir, "analysis_results_overview_20260911.md"), useBytes = TRUE)

input_files <- list.files(input_dir, full.names = TRUE, recursive = TRUE)
input_manifest <- data.frame(
  file = substring(normalizePath(input_files, winslash = "/"), nchar(analysis_root) + 2),
  bytes = file.info(input_files)$size,
  sha256 = vapply(input_files, digest, character(1), algo = "sha256", file = TRUE),
  role = "frozen_analysis_input", stringsAsFactors = FALSE)
write_csv8(input_manifest, file.path(validation_dir, "input_manifest_sha256.csv"))

all_files <- list.files(analysis_root, full.names = TRUE, recursive = TRUE)
all_files <- all_files[!grepl("package_manifest_sha256.csv$", all_files)]
package_manifest <- data.frame(
  file = substring(normalizePath(all_files, winslash = "/"), nchar(analysis_root) + 2),
  bytes = file.info(all_files)$size,
  sha256 = vapply(all_files, digest, character(1), algo = "sha256", file = TRUE),
  stringsAsFactors = FALSE)
write_csv8(package_manifest, file.path(validation_dir, "package_manifest_sha256.csv"))

summary <- list(
  analysis_date = as.character(Sys.Date()), plan_version = "v3.1", node_version = "Gate6_eight_nodes_locked",
  standard_nma_models = nrow(main_status), standard_nma_success = all(main_status$status == "SUCCESS"),
  sensitivity_success = sum(sens_status$status == "SUCCESS"), sensitivity_not_run = sum(sens_status$status != "SUCCESS"),
  duration_nmr_models = nrow(reg_coef), cnma_models = nrow(cnma_status),
  cnma_full_rank = all(cnma_status$active_parameters == cnma_status$active_rank),
  cinema_manual_complete = FALSE, rob_men_complete = FALSE,
  excluded_studies = c("24", "26", "28", "33")
)
write_json(summary, file.path(validation_dir, "run_summary.json"), pretty = TRUE, auto_unbox = TRUE)

cat("PACKAGE_FINALIZED\n")
print(summary)
