options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(metafor)
})

try(Sys.setlocale("LC_ALL", "English_United States.utf8"), silent = TRUE)

args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
base_dir <- normalizePath(Sys.getenv("PAIRWISE_ANALYSIS_ROOT", unset = script_dir0), winslash = "/", mustWork = TRUE)
input_file <- file.path(base_dir, "01_inputs", "pairwise_model_input_READY_20260923.csv")
sensitivity_file <- file.path(base_dir, "01_inputs", "shared_control_GLS_sensitivity_20260923.csv")
output_dir <- file.path(base_dir, "formal_model_run_20260923")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

read_utf8_csv <- function(path) {
  read.csv(path, check.names = FALSE, fileEncoding = "UTF-8-BOM", na.strings = c("", "NA"))
}

write_utf8_csv <- function(x, name) {
  write.csv(x, file.path(output_dir, name), row.names = FALSE, fileEncoding = "UTF-8")
}

safe_num <- function(x) suppressWarnings(as.numeric(x))

dat <- read_utf8_csv(input_file)
dat$study_id <- sprintf("%02d", as.integer(dat$study_id))
dat$TE <- safe_num(dat$TE)
dat$seTE <- safe_num(dat$seTE)

expected_columns <- c(
  "audit_id", "study_id", "author_year", "outcome", "comparator_type",
  "active_node", "effect_measure", "TE", "seTE", "direction",
  "model_eligibility", "combination_status"
)
missing_columns <- setdiff(expected_columns, names(dat))
if (length(missing_columns) > 0) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}

if (nrow(dat) != 79) stop("Expected 79 model-ready rows; found ", nrow(dat))
if (any(!is.finite(dat$TE))) stop("Non-finite TE found")
if (any(!is.finite(dat$seTE) | dat$seTE <= 0)) stop("Invalid seTE found")
approved_eligibility <- c(
  "ELIGIBLE",
  "ELIGIBLE_WITH_N_METADATA_GAP",
  "PASS_WITH_EXPLICIT_APPROXIMATION",
  "PASS_WITH_ICC_SENSITIVITY"
)
if (any(!dat$model_eligibility %in% approved_eligibility)) {
  stop("Unapproved model eligibility status found")
}
if (any(dat$direction != "positive_favours_intervention_or_treat1")) stop("Unexpected effect direction")
if (any(dat$comparator_type %in% c("UC/WL", "ME") == FALSE)) stop("Unexpected comparator")
if (any(dat$active_node %in% c("UC/WL", "ME"))) stop("Control node found on active side")
if (any(duplicated(dat[c("study_id", "outcome", "comparator_type")]))) {
  stop("Duplicate study x outcome x comparator rows found")
}

metric_expected <- c(PA = "SMD", SB = "SMD", Screen = "MD", Sleep = "MD")
for (o in names(metric_expected)) {
  observed <- unique(dat$effect_measure[dat$outcome == o])
  if (length(observed) != 1 || observed != metric_expected[[o]]) {
    stop("Unexpected effect measure for ", o, ": ", paste(observed, collapse = ","))
  }
}

outcome_order <- c("PA", "SB", "Screen", "Sleep")
comparator_order <- c("UC/WL", "ME")
expected_groups <- expand.grid(
  outcome = outcome_order,
  comparator_type = comparator_order,
  stringsAsFactors = FALSE
)
expected_groups <- expected_groups[order(
  match(expected_groups$outcome, outcome_order),
  match(expected_groups$comparator_type, comparator_order)
), ]

group_counts <- aggregate(
  audit_id ~ outcome + comparator_type,
  data = dat,
  FUN = length
)
names(group_counts)[3] <- "k"
group_counts <- merge(expected_groups, group_counts, by = c("outcome", "comparator_type"), all.x = TRUE)
if (nrow(group_counts) != 8 || any(is.na(group_counts$k)) || any(group_counts$k < 2)) {
  stop("Eight poolable outcome x comparator groups were not found")
}

run_reml_with_retry <- function(d, test_method) {
  controls <- list(
    default = list(),
    damped_fisher = list(stepadj = 0.5, maxiter = 10000),
    nlminb = list(optimizer = "nlminb", maxiter = 10000),
    optim = list(optimizer = "optim", maxiter = 10000)
  )
  errors <- character()
  for (nm in names(controls)) {
    fit <- tryCatch(
      rma.uni(
        yi = TE, sei = seTE, data = d,
        method = "REML", test = test_method,
        control = controls[[nm]]
      ),
      error = function(e) e
    )
    if (!inherits(fit, "error")) {
      attr(fit, "fit_attempt") <- nm
      return(fit)
    }
    errors <- c(errors, paste0(nm, ": ", conditionMessage(fit)))
  }
  stop("All REML fitting attempts failed: ", paste(errors, collapse = " | "))
}

fit_pairwise <- function(d) {
  fit_z <- run_reml_with_retry(d, "z")
  fit_hk <- run_reml_with_retry(d, "knha")

  est <- as.numeric(fit_z$b)
  wald_lb <- as.numeric(fit_z$ci.lb)
  wald_ub <- as.numeric(fit_z$ci.ub)
  hk_lb <- as.numeric(fit_hk$ci.lb)
  hk_ub <- as.numeric(fit_hk$ci.ub)

  wald_half <- max(est - wald_lb, wald_ub - est)
  hk_half <- max(est - hk_lb, hk_ub - est)
  selected_half <- max(wald_half, hk_half)
  selected_method <- if (hk_half + 1e-12 >= wald_half) {
    "Hartung-Knapp"
  } else {
    "Wald safeguard because Hartung-Knapp was narrower"
  }

  pred <- if (nrow(d) >= 3) {
    tryCatch(predict(fit_hk), error = function(e) NULL)
  } else {
    NULL
  }
  pred_lb_raw <- if (is.null(pred)) NA_real_ else as.numeric(pred$pi.lb)
  pred_ub_raw <- if (is.null(pred)) NA_real_ else as.numeric(pred$pi.ub)
  pred_half_raw <- if (is.null(pred)) NA_real_ else max(est - pred_lb_raw, pred_ub_raw - est)
  pred_half_selected <- if (is.null(pred)) NA_real_ else max(pred_half_raw, selected_half)

  list(
    fit_z = fit_z,
    fit_hk = fit_hk,
    estimate = est,
    wald_lb = wald_lb,
    wald_ub = wald_ub,
    hk_lb = hk_lb,
    hk_ub = hk_ub,
    selected_lb = est - selected_half,
    selected_ub = est + selected_half,
    selected_method = selected_method,
    pred_lb = if (is.null(pred)) NA_real_ else est - pred_half_selected,
    pred_ub = if (is.null(pred)) NA_real_ else est + pred_half_selected,
    pred_lb_raw = pred_lb_raw,
    pred_ub_raw = pred_ub_raw,
    pred_safeguard_applied = if (is.null(pred)) FALSE else pred_half_selected > pred_half_raw + 1e-12,
    fit_attempt_z = attr(fit_z, "fit_attempt"),
    fit_attempt_hk = attr(fit_hk, "fit_attempt")
  )
}

model_results <- list()
study_results <- list()
loo_results <- list()
influence_results <- list()
bias_results <- list()
model_status <- list()

for (i in seq_len(nrow(expected_groups))) {
  outcome_i <- expected_groups$outcome[i]
  comparator_i <- expected_groups$comparator_type[i]
  d <- dat[dat$outcome == outcome_i & dat$comparator_type == comparator_i, , drop = FALSE]
  d <- d[order(as.integer(d$study_id), d$author_year), , drop = FALSE]
  k <- nrow(d)
  cat("FITTING", outcome_i, "vs", comparator_i, "k=", k, "\n")
  fit <- fit_pairwise(d)
  fit_z <- fit$fit_z
  fit_hk <- fit$fit_hk
  model_id <- paste(outcome_i, gsub("/", "_", comparator_i), sep = "_")
  weights_pct <- as.numeric(weights(fit_z))

  if (abs(sum(weights_pct) - 100) > 1e-6) stop("Weights do not sum to 100 for ", model_id)

  model_results[[model_id]] <- data.frame(
    model_id = model_id,
    outcome = outcome_i,
    comparator_type = comparator_i,
    effect_measure = unique(d$effect_measure),
    unit = ifelse(outcome_i %in% c("Screen", "Sleep"), "min/day", "SMD"),
    k = k,
    pooled_effect = fit$estimate,
    ci_lower_primary = fit$selected_lb,
    ci_upper_primary = fit$selected_ub,
    ci_method_primary = fit$selected_method,
    ci_lower_hk = fit$hk_lb,
    ci_upper_hk = fit$hk_ub,
    p_hk = as.numeric(fit_hk$pval),
    ci_lower_wald = fit$wald_lb,
    ci_upper_wald = fit$wald_ub,
    p_wald = as.numeric(fit_z$pval),
    tau = sqrt(as.numeric(fit_z$tau2)),
    tau2 = as.numeric(fit_z$tau2),
    I2_pct = as.numeric(fit_z$I2),
    H2 = as.numeric(fit_z$H2),
    Q = as.numeric(fit_z$QE),
    Q_df = as.integer(fit_z$k - fit_z$p),
    Q_p = as.numeric(fit_z$QEp),
    prediction_lower_95 = fit$pred_lb,
    prediction_upper_95 = fit$pred_ub,
    prediction_lower_95_native_hk = fit$pred_lb_raw,
    prediction_upper_95_native_hk = fit$pred_ub_raw,
    prediction_interval_safeguard_applied = fit$pred_safeguard_applied,
    prediction_interval_status = ifelse(
      k < 3,
      "NOT_ESTIMATED_K_LT_3",
      ifelse(k < 5, "ESTIMATED_HIGHLY_UNCERTAIN_K_LT_5", "ESTIMATED")
    ),
    tau2_estimator = "REML",
    optimizer_path = paste0("z=", fit$fit_attempt_z, "; HK=", fit$fit_attempt_hk),
    pooling_model = "Random-effects inverse-variance",
    direction = "Positive values favour intervention; for SB and Screen positive values indicate greater reductions",
    stringsAsFactors = FALSE
  )

  study_results[[model_id]] <- data.frame(
    model_id = model_id,
    outcome = outcome_i,
    comparator_type = comparator_i,
    audit_id = d$audit_id,
    study_id = d$study_id,
    author_year = d$author_year,
    active_node = d$active_node,
    effect_measure = d$effect_measure,
    TE = d$TE,
    seTE = d$seTE,
    ci_lower_95 = d$TE - qnorm(0.975) * d$seTE,
    ci_upper_95 = d$TE + qnorm(0.975) * d$seTE,
    random_effect_weight_pct = weights_pct,
    combination_status = d$combination_status,
    sensitivity_group = d$sensitivity_group,
    source_effect_id = d$source_effect_id,
    source_anchor = d$source_anchor,
    stringsAsFactors = FALSE
  )

  if (k >= 3) {
    for (j in seq_len(k)) {
      d_loo <- d[-j, , drop = FALSE]
      fit_loo <- fit_pairwise(d_loo)
      loo_results[[paste(model_id, j, sep = "_")]] <- data.frame(
        model_id = model_id,
        omitted_audit_id = d$audit_id[j],
        omitted_study = d$author_year[j],
        k_remaining = nrow(d_loo),
        pooled_effect = fit_loo$estimate,
        ci_lower_primary = fit_loo$selected_lb,
        ci_upper_primary = fit_loo$selected_ub,
        ci_method_primary = fit_loo$selected_method,
        tau2 = as.numeric(fit_loo$fit_z$tau2),
        I2_pct = as.numeric(fit_loo$fit_z$I2),
        optimizer_path = paste0("z=", fit_loo$fit_attempt_z, "; HK=", fit_loo$fit_attempt_hk),
        stringsAsFactors = FALSE
      )
    }

    hat <- tryCatch(as.numeric(hatvalues(fit_z)), error = function(e) rep(NA_real_, k))
    cook <- tryCatch(as.numeric(cooks.distance(fit_z)), error = function(e) rep(NA_real_, k))
    rst <- tryCatch(as.numeric(rstudent(fit_z)$z), error = function(e) rep(NA_real_, k))
    influence_results[[model_id]] <- data.frame(
      model_id = model_id,
      audit_id = d$audit_id,
      study_id = d$study_id,
      author_year = d$author_year,
      hat_value = hat,
      cooks_distance = cook,
      externally_standardised_residual = rst,
      screening_flag = ifelse(
        (!is.na(cook) & cook > 4 / k) |
          (!is.na(rst) & abs(rst) > 2) |
          (!is.na(hat) & hat > 2 / k),
        "REVIEW", "NO_FLAG"
      ),
      note = "Influence thresholds are screening rules, not exclusion rules.",
      stringsAsFactors = FALSE
    )
  }

  if (k >= 10 && length(unique(round(d$seTE, 12))) >= 5) {
    egger <- tryCatch(regtest(fit_z, model = "rma", predictor = "sei"), error = function(e) e)
    if (inherits(egger, "error")) {
      bias_results[[model_id]] <- data.frame(
        model_id = model_id, k = k, assessment = "ATTEMPTED_FAILED",
        test = "Egger-type meta-regression", statistic = NA_real_, p_value = NA_real_,
        interpretation_limit = conditionMessage(egger), stringsAsFactors = FALSE
      )
    } else {
      bias_results[[model_id]] <- data.frame(
        model_id = model_id, k = k, assessment = "EXPLORATORY_TEST_RUN",
        test = "Egger-type meta-regression using standard error predictor",
        statistic = as.numeric(egger$zval), p_value = as.numeric(egger$pval),
        interpretation_limit = "Exploratory only; intervention and design heterogeneity may create funnel asymmetry unrelated to publication bias.",
        stringsAsFactors = FALSE
      )
    }
  } else {
    bias_results[[model_id]] <- data.frame(
      model_id = model_id, k = k, assessment = "NOT_ASSESSED",
      test = "Not run", statistic = NA_real_, p_value = NA_real_,
      interpretation_limit = "Fewer than 10 studies or insufficient precision variation; funnel asymmetry tests would be unreliable.",
      stringsAsFactors = FALSE
    )
  }

  model_status[[model_id]] <- data.frame(
    model_id = model_id,
    status = "SUCCESS",
    k = k,
    input_rows = k,
    unique_studies = length(unique(d$study_id)),
    weight_sum_pct = sum(weights_pct),
    primary_ci_rule = "Hartung-Knapp with safeguard preventing an interval narrower than Wald",
    optimizer_path = paste0("z=", fit$fit_attempt_z, "; HK=", fit$fit_attempt_hk),
    prediction_interval_rule = ifelse(k >= 3, "Reported from the Hartung-Knapp REML model", "Not estimated"),
    leave_one_out = ifelse(k >= 3, "RUN", "NOT_RUN_K_LT_3"),
    influence_diagnostics = ifelse(k >= 3, "RUN", "NOT_RUN_K_LT_3"),
    high_risk_of_bias_sensitivity = "NOT_RUN_NO_OUTCOME_SPECIFIC_ROB_FIELD_IN_MODEL_INPUT",
    stringsAsFactors = FALSE
  )
}

model_results_df <- do.call(rbind, model_results)
study_results_df <- do.call(rbind, study_results)
loo_results_df <- do.call(rbind, loo_results)
influence_results_df <- do.call(rbind, influence_results)
bias_results_df <- do.call(rbind, bias_results)
model_status_df <- do.call(rbind, model_status)
rownames(model_results_df) <- NULL
rownames(study_results_df) <- NULL
rownames(loo_results_df) <- NULL
rownames(influence_results_df) <- NULL
rownames(bias_results_df) <- NULL
rownames(model_status_df) <- NULL

# Replace one resolved shared-control row at a time with each prespecified
# within-study covariance sensitivity scenario and refit its parent model.
sens <- read_utf8_csv(sensitivity_file)
sens$TE <- safe_num(sens$TE)
sens$seTE <- safe_num(sens$seTE)
shared_control_model_sensitivity <- list()
for (i in seq_len(nrow(sens))) {
  target <- dat[dat$audit_id == sens$audit_id[i], , drop = FALSE]
  if (nrow(target) != 1) stop("Sensitivity audit_id not uniquely found: ", sens$audit_id[i])
  d <- dat[dat$outcome == target$outcome & dat$comparator_type == target$comparator_type, , drop = FALSE]
  idx <- which(d$audit_id == sens$audit_id[i])
  d$TE[idx] <- sens$TE[i]
  d$seTE[idx] <- sens$seTE[i]
  fit_s <- fit_pairwise(d)
  primary <- model_results_df[
    model_results_df$outcome == target$outcome &
      model_results_df$comparator_type == target$comparator_type,
    , drop = FALSE
  ]
  shared_control_model_sensitivity[[i]] <- data.frame(
    model_id = primary$model_id,
    replaced_audit_id = sens$audit_id[i],
    scenario_id = sens$scenario_id[i],
    scenario = sens$scenario[i],
    k = nrow(d),
    pooled_effect = fit_s$estimate,
    ci_lower_primary = fit_s$selected_lb,
    ci_upper_primary = fit_s$selected_ub,
    ci_method_primary = fit_s$selected_method,
    tau2 = as.numeric(fit_s$fit_z$tau2),
    I2_pct = as.numeric(fit_s$fit_z$I2),
    optimizer_path = paste0("z=", fit_s$fit_attempt_z, "; HK=", fit_s$fit_attempt_hk),
    delta_from_primary = fit_s$estimate - primary$pooled_effect,
    stringsAsFactors = FALSE
  )
}
shared_control_model_sensitivity_df <- do.call(rbind, shared_control_model_sensitivity)

validation <- data.frame(
  check = c(
    "input_rows", "model_count", "successful_model_count", "study_result_rows",
    "duplicate_study_outcome_comparator", "invalid_te", "invalid_sete",
    "control_on_active_side", "weight_sum_failures", "missing_primary_ci",
    "missing_prediction_interval", "loo_rows", "influence_rows",
    "shared_control_model_sensitivity_rows"
  ),
  result = c(
    nrow(dat), nrow(model_results_df), sum(model_status_df$status == "SUCCESS"),
    nrow(study_results_df),
    sum(duplicated(dat[c("study_id", "outcome", "comparator_type")])),
    sum(!is.finite(dat$TE)), sum(!is.finite(dat$seTE) | dat$seTE <= 0),
    sum(dat$active_node %in% c("UC/WL", "ME")),
    sum(abs(model_status_df$weight_sum_pct - 100) > 1e-6),
    sum(!is.finite(model_results_df$ci_lower_primary) | !is.finite(model_results_df$ci_upper_primary)),
    sum(model_results_df$k >= 3 & (!is.finite(model_results_df$prediction_lower_95) |
      !is.finite(model_results_df$prediction_upper_95))),
    nrow(loo_results_df), nrow(influence_results_df),
    nrow(shared_control_model_sensitivity_df)
  ),
  expected = c("79", "8", "8", "79", "0", "0", "0", "0", "0", "0", "0", "79", "79", "21"),
  stringsAsFactors = FALSE
)
validation$pass <- as.character(validation$result) == validation$expected
if (!all(validation$pass)) {
  write_utf8_csv(validation, "pairwise_validation_checks.csv")
  stop("Post-model validation failed")
}

write_utf8_csv(model_results_df, "pairwise_model_results.csv")
write_utf8_csv(model_status_df, "pairwise_model_status.csv")
write_utf8_csv(study_results_df, "pairwise_study_results_and_weights.csv")
write_utf8_csv(loo_results_df, "pairwise_leave_one_out.csv")
write_utf8_csv(influence_results_df, "pairwise_influence_diagnostics.csv")
write_utf8_csv(shared_control_model_sensitivity_df, "pairwise_shared_control_sensitivity.csv")
write_utf8_csv(bias_results_df, "pairwise_small_study_effects.csv")
write_utf8_csv(validation, "pairwise_validation_checks.csv")

capture.output(sessionInfo(), file = file.path(output_dir, "R_sessionInfo.txt"))
saveRDS(
  list(
    model_results = model_results_df,
    model_status = model_status_df,
    study_results = study_results_df,
    leave_one_out = loo_results_df,
    influence = influence_results_df,
    shared_control_sensitivity = shared_control_model_sensitivity_df,
    small_study_effects = bias_results_df,
    validation = validation
  ),
  file.path(output_dir, "pairwise_formal_analysis_objects.rds")
)

cat("FORMAL_PAIRWISE_META_ANALYSIS_COMPLETE\n")
cat("Output directory:", output_dir, "\n")
print(model_results_df[, c(
  "model_id", "k", "pooled_effect", "ci_lower_primary", "ci_upper_primary",
  "ci_method_primary", "tau2", "I2_pct", "prediction_lower_95", "prediction_upper_95"
)], row.names = FALSE)
print(validation, row.names = FALSE)
