# Portability changes

Only release copies were edited. Model formulas, contrast directions, component definitions, covariance computations, selection filters, numerical thresholds and validation rules were retained.

## `09_scripts/00_common.R`

- Removed machine-specific R library paths; use standard R libraries or R_LIBS_USER.
- Optional NMA_ANALYSIS_ROOT; default remains the repository parent of 09_scripts.

## `09_scripts/01_run_standard_nma.R`

- No code changes; UTF-8/LF text normalisation only.

## `09_scripts/02_run_sensitivity_meta_regression.R`

- No code changes; UTF-8/LF text normalisation only.

## `09_scripts/03_run_cnma.R`

- No code changes; UTF-8/LF text normalisation only.

## `09_scripts/04_finalize_package.R`

- No code changes; UTF-8/LF text normalisation only.

## `09_scripts/05_verify_numeric_results.R`

- Updated the stale fixed sensitivity-model count to validate the optional S07 branch against its actual input condition; kept the original 40 base scenarios, duplicate checks and fit-success requirement. No analysis/model formulas were changed.

## `09_scripts/11_run_robmen_pa_small_study.R`

- Removed machine-specific R library paths; use standard R libraries or R_LIBS_USER.
- Replaced the personal ROB-MEN working directory with the repository analysis root.

## `09_scripts/13_run_pa_measurement_method_nmr.R`

- Removed machine-specific R library paths; use standard R libraries or R_LIBS_USER.
- Replaced the personal root fallback with a script-relative root; retained NMA_ANALYSIS_ROOT.

## `09_scripts/99_run_all.R`

- Selected the Rscript executable for Windows or Unix; core run order unchanged.

## `pairwise/run_formal_pairwise_meta_analysis_20260923.R`

- Replaced the personal base directory with a script-relative root or PAIRWISE_ANALYSIS_ROOT.
- Input files are read from pairwise/01_inputs; model formulas, validation and output filenames unchanged.
