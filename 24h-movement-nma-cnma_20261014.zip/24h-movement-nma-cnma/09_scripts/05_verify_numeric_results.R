args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
source(file.path(script_dir0, "00_common.R"), encoding = "UTF-8")

primary <- read_input("nma_primary_gate6.csv")
icc_qa <- list()
for (o in outcomes) {
  low <- readRDS(file.path(sensitivity_dir, "models", paste0("S02_EXTERNAL_ICC_LOW_", o, ".rds")))$input_observed
  high <- readRDS(file.path(sensitivity_dir, "models", paste0("S03_EXTERNAL_ICC_HIGH_", o, ".rds")))$input_observed
  ids <- primary$effect_id[primary$outcome == o & grepl("EXTERNAL_ICC", primary$sensitivity_group)]
  if (!length(ids)) next
  z <- primary %>% filter(outcome == o, effect_id %in% ids) %>% select(outcome, study_id, effect_id, primary_seTE = seTE) %>%
    left_join(low %>% select(effect_id, low_ICC_0_01_seTE = seTE), by = "effect_id") %>%
    left_join(high %>% select(effect_id, high_ICC_0_10_seTE = seTE), by = "effect_id") %>%
    mutate(low_high_differ = abs(low_ICC_0_01_seTE - high_ICC_0_10_seTE) > 1e-12,
           ordered = low_ICC_0_01_seTE < high_ICC_0_10_seTE)
  icc_qa[[o]] <- z
}
icc_qa_df <- bind_rows(icc_qa)
write_csv8(icc_qa_df, file.path(validation_dir, "ICC_scenario_input_QA.csv"))

standard_tests <- read_csv(file.path(standard_dir, "logs", "standard_NMA_validation.csv"), show_col_types = FALSE)
standard_status <- read_csv(file.path(standard_dir, "logs", "standard_NMA_model_status.csv"), show_col_types = FALSE)
sens_status <- read_csv(file.path(sensitivity_dir, "sensitivity_model_status.csv"), show_col_types = FALSE)
# The analysis script contains an optional S07 branch for Study 29 PA.
# Validate the branch against the actual input rather than assuming it is absent.
all_source_rows <- read_input("nma_all_rows.csv")
s07_expected <- as.integer(sum(all_source_rows$study_id == "29" &
  all_source_rows$analysis_status == "sensitivity" &
  all_source_rows$outcome == "\u8eab\u4f53\u6d3b\u52a8", na.rm = TRUE) == 1L)
s07_present <- sum(sens_status$sensitivity_id == "S07_INCLUDE_STUDY29_PA" &
  sens_status$outcome == "PA")

sd_qa <- read_csv(file.path(sensitivity_dir, "alternative_SD_input_QA.csv"), show_col_types = FALSE)
sd_coverage <- read_csv(file.path(sensitivity_dir, "alternative_SD_coverage.csv"), show_col_types = FALSE)
reg_status <- read_csv(file.path(regression_dir, "duration_NMR_model_status.csv"), show_col_types = FALSE)
cnma_status <- read_csv(file.path(cnma_dir, "CNMA_parent_model_registry.csv"), show_col_types = FALSE)
loo <- read_csv(file.path(cnma_dir, "diagnostics", "CNMA_leave_one_study_rank.csv"), show_col_types = FALSE)
covqa <- read_csv(file.path(cnma_dir, "diagnostics", "CNMA_multiarm_covariance_QA.csv"), show_col_types = FALSE)

tests <- data.frame(
  check = c(
    "standard_four_models_success", "standard_all_validation_pass", "standard_no_model_warnings",
    "sensitivity_expected_models_success", "external_SD_18_models_success",
    "external_SD_registry_transformations_valid", "external_SD_missing_values_explicit",
    "ICC_low_high_inputs_changed_and_ordered", "duration_two_models_success", "study17_excluded_only_from_PA_duration",
    "cnma_20_models_success", "cnma_all_active_matrices_full_rank", "cnma_all_residual_df_positive",
    "cnma_no_leave_one_study_rank_loss", "cnma_parent_nesting_verified", "cnma_additivity_q_nonnegative",
    "cnma_covariance_blocks_valid", "cinema_left_pending"
  ),
  pass = c(
    nrow(standard_status) == 4L && all(standard_status$status == "SUCCESS"),
    all(standard_tests$pass), all(standard_status$warning_count == 0),
    nrow(sens_status) == 40L + s07_expected && s07_present == s07_expected &&
      !anyDuplicated(sens_status[c("sensitivity_id", "outcome")]) && all(sens_status$status == "SUCCESS"),
    sum(grepl("^S10", sens_status$sensitivity_id) & sens_status$status == "SUCCESS") == 18L,
    nrow(sd_qa) == 16L && all(sd_qa$transformation_valid) &&
      all(abs(sd_qa$alternative_TE - sd_qa$primary_TE * sd_qa$primary_sd / sd_qa$alternative_sd) < 1e-12) &&
      all(abs(sd_qa$alternative_seTE - sd_qa$primary_seTE * sd_qa$primary_sd / sd_qa$alternative_sd) < 1e-12),
    sum(sd_coverage$coverage_status == "NO_NUMERIC_ALTERNATIVE_RETAIN_EXCLUSION_CHECK") == 9L,
    nrow(icc_qa_df) > 0 && all(icc_qa_df$low_high_differ) && all(icc_qa_df$ordered),
    nrow(reg_status) == 2L && all(reg_status$status == "SUCCESS"),
    identical(as.character(reg_status$missing_duration_studies[reg_status$outcome == "PA"]), "17"),
    nrow(cnma_status) == 20L && all(grepl("^FIT_SUCCESS", cnma_status$status)),
    all(cnma_status$active_parameters == cnma_status$active_rank), all(cnma_status$residual_df > 0),
    !any(loo$rank_loss), all(cnma_status$nested_X_in_parent),
    all(cnma_status$Q_difference >= -1e-8), all(covqa$status == "PASS"),
    file.exists(file.path(cinema_dir, "CINeMA_manual_adjudication_template.csv"))
  ),
  stringsAsFactors = FALSE
)
tests$status <- ifelse(tests$pass, "PASS", "FAIL")
write_csv8(tests, file.path(validation_dir, "critical_numeric_verification.csv"))
if (!all(tests$pass)) stop("Critical numeric verification failed: ", paste(tests$check[!tests$pass], collapse = "; "))

cat("CRITICAL_NUMERIC_VERIFICATION_PASS\n")
print(tests)
