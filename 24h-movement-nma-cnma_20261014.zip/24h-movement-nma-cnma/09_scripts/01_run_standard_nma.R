args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
source(file.path(script_dir0, "00_common.R"), encoding = "UTF-8")

model_input <- read_input("nma_model_input_complete_multiarm_gate6.csv")
primary_input <- read_input("nma_primary_gate6.csv")

subdirs <- c("models", "effects", "geometry", "rankings", "inconsistency", "logs")
for (d in subdirs) dir.create(file.path(standard_dir, d), recursive = TRUE, showWarnings = FALSE)

status <- effects_ref <- effects_all <- heterogeneity <- rankings <- nodes_out <- edges_out <- list()
global_inc <- local_inc <- contribution <- tests <- list()

for (outcome in outcomes) {
  x <- model_input[model_input$outcome == outcome, , drop = FALSE]
  x0 <- primary_input[primary_input$outcome == outcome, , drop = FALSE]
  fit_run <- fit_netmeta(x)
  fit <- fit_run$value
  saveRDS(list(model = fit, input = x, warnings = fit_run$warnings, call = fit$call),
          file.path(standard_dir, "models", paste0(outcome, "_standard_NMA_REML.rds")))
  writeLines(capture.output(summary(fit)), file.path(standard_dir, "models", paste0(outcome, "_summary.txt")), useBytes = TRUE)

  status[[outcome]] <- data.frame(
    outcome = outcome, outcome_label = outcome_labels[[outcome]], status = "SUCCESS",
    studies = fit$k, primary_rows = nrow(x0), complete_pairwise_rows = nrow(x),
    nodes = length(fit$trts), designs = fit$d, reference = fit$reference.group,
    effect_measure = fit$sm, unit = unique(x$analysis_unit), method_tau = fit$method.tau,
    tau = fit$tau, tau2 = fit$tau^2, I2 = fit$I2, Q_total = fit$Q, df_Q_total = fit$df.Q,
    p_Q_total = fit$pval.Q, Q_heterogeneity = fit$Q.heterogeneity,
    df_Q_heterogeneity = fit$df.Q.heterogeneity, p_Q_heterogeneity = fit$pval.Q.heterogeneity,
    Q_inconsistency = fit$Q.inconsistency, df_Q_inconsistency = fit$df.Q.inconsistency,
    p_Q_inconsistency = fit$pval.Q.inconsistency, warning_count = length(fit_run$warnings),
    warnings = paste(fit_run$warnings, collapse = " | "), stringsAsFactors = FALSE)

  effects_ref[[outcome]] <- extract_ref_effects(fit, outcome)
  effects_all[[outcome]] <- extract_all_effects(fit, outcome)
  heterogeneity[[outcome]] <- data.frame(
    outcome = outcome, studies = fit$k, nodes = length(fit$trts), tau = fit$tau, tau2 = fit$tau^2,
    I2 = fit$I2, lower_I2 = fit$lower.I2, upper_I2 = fit$upper.I2,
    Q = fit$Q, df = fit$df.Q, p_value = fit$pval.Q, stringsAsFactors = FALSE)

  nr <- netrank(fit, small.values = "bad", common = FALSE, random = TRUE)
  rankings[[outcome]] <- data.frame(outcome = outcome, treatment = names(nr$ranking.random),
                                    P_score = as.numeric(nr$ranking.random),
                                    rank = rank(-as.numeric(nr$ranking.random), ties.method = "min"),
                                    interpretation = "descriptive_only", stringsAsFactors = FALSE)
  league <- netleague(fit, common = FALSE, random = TRUE, ci = TRUE, digits = 4)$random
  write_csv8(data.frame(treatment = rownames(league), league, check.names = FALSE),
             file.path(standard_dir, "effects", paste0(outcome, "_league_table_random.csv")))

  nodes <- sort(unique(c(x$treat1_node, x$treat2_node)))
  nodes_out[[outcome]] <- bind_rows(lapply(nodes, function(node) {
    g <- x0[x0$treat1_node == node | x0$treat2_node == node, , drop = FALSE]
    data.frame(outcome = outcome, node = node, studies = n_distinct(g$study_id), direct_rows = nrow(g),
               reference = node == reference_node, stringsAsFactors = FALSE)
  }))
  x$edge <- paste(pmin(x$treat1_node, x$treat2_node), pmax(x$treat1_node, x$treat2_node), sep = " | ")
  edges_out[[outcome]] <- x %>% group_by(edge) %>% summarise(
    outcome = first(outcome), treatment_a = min(c(treat1_node, treat2_node)),
    treatment_b = max(c(treat1_node, treat2_node)), studies = n_distinct(study_id),
    study_ids = paste(sort(unique(study_id)), collapse = ";"), .groups = "drop")

  ns <- try(capture_warning(netsplit(fit, common = FALSE, random = TRUE)), silent = TRUE)
  if (!inherits(ns, "try-error")) {
    z <- ns$value$compare.random; z$outcome <- outcome
    z$direct_TE <- ns$value$direct.random$TE; z$indirect_TE <- ns$value$indirect.random$TE
    z$estimable <- is.finite(z$TE) & is.finite(z$p)
    local_inc[[outcome]] <- z
  }
  dd <- try(capture_warning(decomp.design(fit)), silent = TRUE)
  if (!inherits(dd, "try-error")) {
    z <- as.data.frame(dd$value$Q.decomp); z$component <- rownames(z); rownames(z) <- NULL; z$outcome <- outcome
    global_inc[[outcome]] <- z
  }
  nc <- try(capture_warning(netcontrib(fit)), silent = TRUE)
  if (!inherits(nc, "try-error")) {
    cm <- nc$value$random
    contribution[[outcome]] <- bind_rows(lapply(seq_len(nrow(cm)), function(i) {
      data.frame(outcome = outcome, network_comparison = rownames(cm)[i],
                 direct_comparison = colnames(cm), percent_contribution = 100 * as.numeric(cm[i, ]),
                 stringsAsFactors = FALSE)
    }))
  }

  tests[[outcome]] <- data.frame(
    outcome = outcome,
    check = c("finite_effects", "positive_SE", "no_self_comparison", "connected", "reference_present", "REML", "no_warnings"),
    pass = c(all(is.finite(x$TE)), all(is.finite(x$seTE) & x$seTE > 0), all(x$treat1_node != x$treat2_node),
             is_connected(x), reference_node %in% nodes, identical(fit$method.tau, "REML"), length(fit_run$warnings) == 0L),
    stringsAsFactors = FALSE)

  png(file.path(figure_dir, paste0(outcome, "_NMA_network.png")), width = 2400, height = 2100, res = 300)
  netgraph(fit, plastic = FALSE, thickness = "number.of.studies", multiarm = TRUE,
           col = "#24476B", col.points = "#DCE6F1", cex.points = 4, cex = .8)
  title(main = paste0(outcome_labels[[outcome]], ": Gate 6 network")); dev.off()

  fp <- effects_ref[[outcome]]
  fp$treatment <- factor(fp$treatment, levels = fp$treatment[order(fp$TE)])
  p <- ggplot(fp, aes(x = TE, y = treatment)) +
    geom_vline(xintercept = 0, colour = "#5B6573", linewidth = .45) +
    geom_segment(aes(x = lower, xend = upper, yend = treatment), colour = "#3E5368", linewidth = .65) +
    geom_point(shape = 22, fill = "#4C78A8", colour = "#24476B", size = 3) +
    labs(title = paste0(outcome_labels[[outcome]], ": random-effects NMA"),
         subtitle = paste0("Reference: ", reference_node, "; positive values favour treatment"),
         x = ifelse(fit$sm == "SMD", "Hedges' g", "Mean difference (min/day)"), y = NULL) +
    theme_classic(base_size = 10) + theme(plot.title = element_text(face = "bold"))
  ggsave(file.path(figure_dir, paste0(outcome, "_NMA_forest.png")), p, width = 8.5, height = 5.6, dpi = 300, bg = "white")
  ggsave(file.path(figure_dir, paste0(outcome, "_NMA_forest.pdf")), p, width = 8.5, height = 5.6, bg = "white")
}

write_csv8(bind_rows(status), file.path(standard_dir, "logs", "standard_NMA_model_status.csv"))
write_csv8(bind_rows(tests), file.path(standard_dir, "logs", "standard_NMA_validation.csv"))
write_csv8(bind_rows(effects_ref), file.path(standard_dir, "effects", "network_effects_vs_UCWL.csv"))
write_csv8(bind_rows(effects_all), file.path(standard_dir, "effects", "network_effects_all_pairs.csv"))
write_csv8(bind_rows(heterogeneity), file.path(standard_dir, "effects", "heterogeneity.csv"))
write_csv8(bind_rows(rankings), file.path(standard_dir, "rankings", "P_scores.csv"))
write_csv8(bind_rows(nodes_out), file.path(standard_dir, "geometry", "network_nodes.csv"))
write_csv8(bind_rows(edges_out), file.path(standard_dir, "geometry", "network_edges.csv"))
if (length(global_inc)) write_csv8(bind_rows(global_inc), file.path(standard_dir, "inconsistency", "global_design_by_treatment.csv"))
if (length(local_inc)) write_csv8(bind_rows(local_inc), file.path(standard_dir, "inconsistency", "node_splitting.csv"))
if (length(contribution)) write_csv8(bind_rows(contribution), file.path(standard_dir, "inconsistency", "contribution_matrix_long.csv"))

writeLines(c(
  paste0("R: ", R.version.string), paste0("netmeta: ", packageVersion("netmeta")),
  paste0("analysis_date: ", Sys.Date()),
  "model: contrast-based frequentist random-effects NMA; common heterogeneity within outcome; REML",
  "input: Gate 6 locked nodes; exact multi-arm closure derived from frozen S matrices",
  "direction: positive values favour treatment for every outcome"
), file.path(standard_dir, "logs", "software_session.txt"), useBytes = TRUE)

cat("STANDARD_NMA_COMPLETE\n")
print(bind_rows(status) %>% select(outcome, studies, nodes, tau2, I2, p_Q_inconsistency, warning_count))
