args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
source(file.path(script_dir0, "00_common.R"), encoding = "UTF-8")

cnma_input <- read_input("cnma_model_input_exact.csv")
arms <- read_input("component_arms_22.csv")
S_long <- read_csv(file.path(input_dir, "S_primary_long.csv"), show_col_types = FALSE)
R_long <- read_csv(file.path(input_dir, "R_long.csv"), show_col_types = FALSE)

component_codes <- c(sprintf("T%02d", 1:5), sprintf("F%02d", 1:9), sprintf("I%02d", 1:8))
if (!all(component_codes %in% names(arms))) stop("Component arm matrix is incomplete")
arm_key <- paste(arms$study_id, arms$arm_id, sep = "|")
if (anyDuplicated(arm_key)) stop("Duplicate study-arm keys")
arm_index <- setNames(seq_len(nrow(arms)), arm_key)

model_specs <- list(
  CNMA_T = list(role = "primary_component_model", components = c("T01", "T02", "T03", "T04")),
  CNMA_T05 = list(role = "prespecified_T05_sensitivity", components = c("T01", "T02", "T03", "T04", "T05")),
  CNMA_F = list(role = "explanatory_function_model", components = c("T01", "T02", "T03", "T04", "F01", "F02", "F03", "F05", "F07", "F09")),
  CNMA_I = list(role = "explanatory_implementation_model", components = c("T01", "T02", "T03", "T04", "I01", "I02", "I06")),
  CNMA_I04 = list(role = "prespecified_I04_sensitivity", components = c("T01", "T02", "T03", "T04", "I01", "I02", "I04", "I06"))
)

component_design <- function(d, components) {
  X <- matrix(0, nrow(d), length(components), dimnames = list(d$effect_id, components))
  for (i in seq_len(nrow(d))) {
    k1 <- paste(d$study_id[i], d$treat1_arm_id[i], sep = "|")
    k2 <- paste(d$study_id[i], d$treat2_arm_id[i], sep = "|")
    i1 <- arm_index[[k1]]; i2 <- arm_index[[k2]]
    if (is.null(i1) || is.null(i2)) stop("Unmatched arm in ", d$effect_id[i])
    X[i, ] <- as.numeric(unlist(arms[i1, components, drop = FALSE], use.names = FALSE)) -
      as.numeric(unlist(arms[i2, components, drop = FALSE], use.names = FALSE))
  }
  X
}

arm_signature_lookup <- function(d, components) {
  used <- unique(c(paste(d$study_id, d$treat1_arm_id, sep = "|"), paste(d$study_id, d$treat2_arm_id, sep = "|")))
  idx <- arm_index[used]
  if (anyNA(idx)) stop("Unmatched arm while making parent")
  A <- as.matrix(arms[as.integer(idx), components, drop = FALSE]); storage.mode(A) <- "numeric"
  sig <- component_signature(A)
  labels <- apply(A, 1, function(z) {
    active <- components[z == 1]
    if (!length(active)) "No active component" else paste(active, collapse = "+")
  })
  data.frame(key = used, signature = sig, combination_label = labels, A, check.names = FALSE, stringsAsFactors = FALSE)
}

make_parent_design <- function(d, components) {
  map <- arm_signature_lookup(d, components)
  sig_lookup <- setNames(map$signature, map$key)
  s1 <- unname(sig_lookup[paste(d$study_id, d$treat1_arm_id, sep = "|")])
  s2 <- unname(sig_lookup[paste(d$study_id, d$treat2_arm_id, sep = "|")])
  nodes <- sort(unique(c(s1, s2)))
  gm <- graph_membership(nodes, s1, s2)
  refs <- unlist(lapply(split(gm$node, gm$component), function(z) if (paste(rep("0", length(components)), collapse = "") %in% z) paste(rep("0", length(components)), collapse = "") else sort(z)[1]), use.names = FALSE)
  columns <- setdiff(nodes, refs)
  Z <- matrix(0, nrow(d), length(columns), dimnames = list(d$effect_id, paste0("P_", columns)))
  for (i in seq_len(nrow(d))) {
    if (s1[i] %in% columns) Z[i, match(s1[i], columns)] <- 1
    if (s2[i] %in% columns) Z[i, match(s2[i], columns)] <- Z[i, match(s2[i], columns)] - 1
  }
  label_map <- map %>% distinct(signature, combination_label)
  list(Z = Z, signature1 = s1, signature2 = s2, membership = gm,
       references = refs, label_map = label_map, same = s1 == s2)
}

dirs <- c("models", "coefficients", "parents", "diagnostics", "predictions")
for (d in dirs) dir.create(file.path(cnma_dir, d), recursive = TRUE, showWarnings = FALSE)

registry <- coef_rows <- support_rows <- parent_nodes <- parent_edges <- same_rows <- loo_rows <- prediction_rows <- covariance_rows <- list()

for (outcome in outcomes) {
  d <- cnma_input[cnma_input$outcome == outcome, , drop = FALSE]
  for (model_name in names(model_specs)) {
    spec <- model_specs[[model_name]]
    components <- spec$components
    if (model_name == "CNMA_F" && outcome == "Sleep") components <- setdiff(components, "F02")
    X <- component_design(d, components)
    block <- build_cnma_blocks(d, X, S_long, R_long)
    parent <- make_parent_design(d, components)
    ord <- match(block$meta$effect_id, d$effect_id)
    Z <- parent$Z[ord, , drop = FALSE]
    s1 <- parent$signature1[ord]; s2 <- parent$signature2[ord]
    fit <- fit_reml(block$y, block$X, block$S, block$R)
    full_rank <- fit$rank == ncol(block$X)
    if (!full_rank || fit$df <= 0 || fit$convergence != "converged") {
      registry[[length(registry) + 1L]] <- data.frame(
        outcome = outcome, model = model_name, role = spec$role, active_components = paste(components, collapse = ";"),
        independent_contrasts = length(block$y), active_parameters = ncol(block$X), active_rank = fit$rank,
        residual_df = fit$df, status = "STOP_NOT_IDENTIFIABLE", stringsAsFactors = FALSE)
      next
    }
    V <- fit$V
    parent_fit <- fit_gls_fixed_v(block$y, Z, V)
    additive_fit_fixed <- fit_gls_fixed_v(block$y, block$X, V)
    rank_parent <- parent_fit$rank; rank_add <- additive_fit_fixed$rank
    nested_rank <- full_rank_basis(cbind(Z, block$X))$rank == rank_parent
    df_diff <- rank_parent - rank_add
    q_diff <- additive_fit_fixed$Q - parent_fit$Q
    if (is.finite(q_diff) && q_diff < 0 && abs(q_diff) < 1e-8) q_diff <- 0
    p_diff <- if (nested_rank && df_diff > 0 && q_diff >= 0) pchisq(q_diff, df_diff, lower.tail = FALSE) else NA_real_
    add_status <- if (!nested_rank || df_diff <= 0 || !is.finite(p_diff)) "not_testable" else if (p_diff < .05) "evidence_against_additivity" else "no_evidence_against_additivity"
    wc <- weighted_condition_number(block$X, V)
    cov_beta <- fit$cov; se <- sqrt(diag(cov_beta)); beta_names <- colnames(block$X)[fit$selected]
    cor_beta <- cov2cor(cov_beta); max_cor <- if (length(cor_beta) > 1) max(abs(cor_beta[row(cor_beta) != col(cor_beta)])) else NA_real_
    gm <- parent$membership
    projection_error <- if (ncol(Z)) max(abs(block$X - Z %*% qr.coef(qr(Z), block$X)), na.rm = TRUE) else max(abs(block$X))

    status <- if (add_status == "evidence_against_additivity") "FIT_SUCCESS_INTERPRETATION_BLOCKED" else "FIT_SUCCESS"
    registry[[length(registry) + 1L]] <- data.frame(
      outcome = outcome, model = model_name, role = spec$role, active_components = paste(components, collapse = ";"),
      inactive_note = ifelse(model_name == "CNMA_F" && outcome == "Sleep", "F02 inactive_insufficient_support", ""),
      studies = n_distinct(d$study_id), independent_contrasts = length(block$y), active_parameters = ncol(block$X),
      active_rank = fit$rank, residual_df = fit$df, weighted_condition_number = wc,
      max_abs_parameter_correlation = max_cor, tau = fit$tau, tau2 = fit$tau2,
      REML_boundary = fit$boundary, convergence = fit$convergence,
      parent_definition = "exact combination of model-specific active component vector",
      parent_nodes = nrow(gm), parent_connected_components = n_distinct(gm$component),
      parent_rank = rank_parent, same_vector_contrasts = sum(parent$same), nested_X_in_parent = nested_rank,
      max_abs_X_minus_parent_projection = projection_error,
      Q_parent_fixed_same_V = parent_fit$Q, Q_additive_fixed_same_V = additive_fit_fixed$Q,
      Q_difference = q_diff, df_difference = df_diff, p_difference = p_diff,
      additive_test_status = add_status,
      cross_subnetwork_note = ifelse(n_distinct(gm$component) > 1,
        "Cross-subnetwork component estimates depend on the additive model and are not direct/indirect network evidence", ""),
      status = status, stringsAsFactors = FALSE)

    coef_rows[[length(coef_rows) + 1L]] <- data.frame(
      outcome = outcome, model = model_name, role = spec$role, component = beta_names,
      beta = as.numeric(fit$beta), se = se, lower = as.numeric(fit$beta - qnorm(.975) * se),
      upper = as.numeric(fit$beta + qnorm(.975) * se), z = as.numeric(fit$beta / se),
      p_value = 2 * pnorm(-abs(as.numeric(fit$beta / se))),
      effect_measure = ifelse(outcome %in% c("PA", "SB"), "SMD", "MD_min_per_day"),
      direction = "positive_favours_component_presence",
      interpretation_status = ifelse(add_status == "evidence_against_additivity", "do_not_interpret_as_independent_component_effect", "model_based_incremental_association"),
      stringsAsFactors = FALSE)

    support_rows[[length(support_rows) + 1L]] <- bind_rows(lapply(seq_along(components), function(j) {
      sw <- abs(block$X[, j]) > 1e-12
      data.frame(outcome = outcome, model = model_name, component = components[j],
                 switching_studies = n_distinct(block$meta$study_id[sw]), switching_contrasts = sum(sw),
                 positive_switches = sum(block$X[, j] > 0), negative_switches = sum(block$X[, j] < 0),
                 stringsAsFactors = FALSE)
    }))

    node_label <- setNames(parent$label_map$combination_label, parent$label_map$signature)
    parent_nodes[[length(parent_nodes) + 1L]] <- gm %>% mutate(
      outcome = outcome, model = model_name, combination_label = unname(node_label[node]),
      reference_within_component = node %in% parent$references)
    ed <- data.frame(outcome = outcome, model = model_name, study_id = block$meta$study_id,
                     effect_id = block$meta$effect_id, combination1 = s1, combination2 = s2,
                     same_vector = s1 == s2, stringsAsFactors = FALSE)
    parent_edges[[length(parent_edges) + 1L]] <- ed
    if (any(parent$same)) same_rows[[length(same_rows) + 1L]] <- ed[ed$same_vector, , drop = FALSE]

    for (study in names(block$study_rows)) {
      keep <- setdiff(seq_len(nrow(block$X)), block$study_rows[[study]])
      rk <- if (length(keep)) full_rank_basis(block$X[keep, , drop = FALSE])$rank else 0L
      loo_rows[[length(loo_rows) + 1L]] <- data.frame(
        outcome = outcome, model = model_name, omitted_study = study,
        rank_after_deletion = rk, full_rank = ncol(block$X), rank_loss = rk < ncol(block$X),
        residual_df_after_deletion = length(keep) - rk, stringsAsFactors = FALSE)
    }

    unique_vectors <- unique(arm_signature_lookup(d, components)[c("signature", "combination_label", components)])
    beta_map <- setNames(as.numeric(fit$beta), beta_names)
    pred <- apply(unique_vectors[, components, drop = FALSE], 1, function(z) sum(as.numeric(z) * beta_map[components]))
    prediction_rows[[length(prediction_rows) + 1L]] <- data.frame(
      outcome = outcome, model = model_name, unique_vectors, predicted_effect_vs_no_active_component = pred,
      prediction_limit = "additive model prediction; cross-subnetwork contrasts may depend entirely on additivity",
      check.names = FALSE, stringsAsFactors = FALSE)

    for (study in names(block$study_rows)) {
      idx <- block$study_rows[[study]]
      covariance_rows[[length(covariance_rows) + 1L]] <- data.frame(
        outcome = outcome, model = model_name, study_id = study, independent_contrasts = length(idx),
        min_eigen_S = min(eigen(block$S[idx, idx, drop = FALSE], symmetric = TRUE, only.values = TRUE)$values),
        min_eigen_R = min(eigen(block$R[idx, idx, drop = FALSE], symmetric = TRUE, only.values = TRUE)$values),
        status = "PASS", stringsAsFactors = FALSE)
    }

    saveRDS(list(fit = fit, parent_fixed_V = parent_fit, additive_fixed_V = additive_fit_fixed,
                 input = d, X_active = block$X, Z_parent = Z, S = block$S, R = block$R,
                 meta = block$meta, components = components, parent = parent),
            file.path(cnma_dir, "models", paste0(outcome, "_", model_name, "_exact_REML.rds")))

    cp <- coef_rows[[length(coef_rows)]]
    cp$component <- factor(cp$component, levels = rev(cp$component))
    p <- ggplot(cp, aes(x = beta, y = component)) +
      geom_vline(xintercept = 0, colour = "#5B6573", linewidth = .45) +
      geom_segment(aes(x = lower, xend = upper, yend = component), colour = "#3E5368", linewidth = .65) +
      geom_point(shape = 22, fill = "#B55A30", colour = "#78391F", size = 2.8) +
      labs(title = paste(outcome_labels[[outcome]], model_name, sep = ": "),
           subtitle = paste0("Model-specific REML; additivity: ", add_status),
           x = ifelse(outcome %in% c("PA", "SB"), "Incremental Hedges' g", "Incremental MD (min/day)"), y = NULL) +
      theme_classic(base_size = 9) + theme(plot.title = element_text(face = "bold"))
    ggsave(file.path(figure_dir, paste0(outcome, "_", model_name, "_components.png")), p,
           width = 7.4, height = max(4.2, .38 * nrow(cp) + 2.2), dpi = 300, bg = "white")
  }
}

registry_df <- bind_rows(registry)
write_csv8(registry_df, file.path(cnma_dir, "CNMA_parent_model_registry.csv"))
write_csv8(bind_rows(coef_rows), file.path(cnma_dir, "coefficients", "CNMA_component_coefficients.csv"))
write_csv8(bind_rows(support_rows), file.path(cnma_dir, "diagnostics", "CNMA_component_switch_support.csv"))
write_csv8(bind_rows(parent_nodes), file.path(cnma_dir, "parents", "CNMA_parent_nodes.csv"))
write_csv8(bind_rows(parent_edges), file.path(cnma_dir, "parents", "CNMA_parent_edges.csv"))
write_csv8(if (length(same_rows)) bind_rows(same_rows) else data.frame(), file.path(cnma_dir, "parents", "CNMA_same_vector_contrasts.csv"))
write_csv8(bind_rows(loo_rows), file.path(cnma_dir, "diagnostics", "CNMA_leave_one_study_rank.csv"))
write_csv8(bind_rows(prediction_rows), file.path(cnma_dir, "predictions", "CNMA_observed_combination_predictions.csv"))
write_csv8(bind_rows(covariance_rows), file.path(cnma_dir, "diagnostics", "CNMA_multiarm_covariance_QA.csv"))

writeLines(c(
  paste0("R: ", R.version.string), paste0("Matrix: ", packageVersion("Matrix")),
  "Estimator: model-specific multivariate profile REML using exact frozen study-block S and R",
  "Additivity test: parent and additive GLS fitted with identical V=S+tau2_additive*R",
  "Parent: exact combinations of each model's active component columns",
  "Inference: Wald normal 95% confidence intervals"
), file.path(cnma_dir, "CNMA_software_session.txt"), useBytes = TRUE)

cat("CNMA_COMPLETE\n")
print(registry_df %>% select(outcome, model, active_parameters, active_rank, residual_df,
                             tau2, parent_connected_components, p_difference, additive_test_status, status))
