args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
script_dir0 <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
source(file.path(script_dir0, "00_common.R"), encoding = "UTF-8")

primary <- read_input("nma_primary_gate6.csv")
model_complete <- read_input("nma_model_input_complete_multiarm_gate6.csv")
links <- read_input("effect_link.csv")
effects_all_source <- read_input("nma_all_rows.csv")
final_effects <- read_input("final_effect_rows.csv")
rob <- read_input("rob_normalized.csv")
characteristics <- read_input("study_characteristics.csv")
arm_map <- read_input("approved_arm_node_mapping_Gate6_locked.csv")
S_long <- read_csv(file.path(input_dir, "S_primary_long.csv"), show_col_types = FALSE)
sd_registry <- read_input("alternative_SD_registry_v1.csv")

dir.create(file.path(sensitivity_dir, "models"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(regression_dir, "models"), recursive = TRUE, showWarnings = FALSE)

rob_code <- c(PA = "PA", SB = "SB", ST = "Screen", SD = "Sleep")

make_icc_scenario <- function(d, new_icc) {
  f <- final_effects %>% mutate(source_effect_row = row_number() + 1L)
  link_key <- links %>% select(study_id, source_effect_row, outcome_code) %>% distinct()
  j <- f %>% filter(grepl("EXTERNAL_ICC", sensitivity_group)) %>%
    inner_join(link_key, by = c("study_id", "source_effect_row")) %>%
    mutate(outcome_code2 = recode(outcome_code, ST = "Screen", SD = "Sleep", .default = outcome_code)) %>%
    transmute(study_id, outcome = outcome_code2, comparison_id,
              old_icc = as.numeric(icc), clusters_i = as.numeric(clusters_intervention),
              clusters_c = as.numeric(clusters_comparator), n_i = as.numeric(n_intervention), n_c = as.numeric(n_comparator))
  z <- d %>% left_join(j, by = c("study_id", "outcome", "comparison_id"))
  idx <- which(is.finite(z$old_icc))
  if (any(grepl("EXTERNAL_ICC", d$sensitivity_group)) && !length(idx)) stop("External ICC rows failed to link")
  if (length(idx)) {
    mbar <- (z$n_i[idx] + z$n_c[idx]) / (z$clusters_i[idx] + z$clusters_c[idx])
    de_old <- 1 + (mbar - 1) * z$old_icc[idx]
    de_new <- 1 + (mbar - 1) * new_icc
    z$seTE[idx] <- z$seTE[idx] * sqrt(de_new / de_old)
    z$variance[idx] <- z$seTE[idx]^2
  }
  z %>% select(all_of(names(d)))
}

make_alternative_sd_scenario <- function(d, registry_rows) {
  r <- registry_rows %>%
    filter(availability == "FROZEN_NUMERIC") %>%
    transmute(effect_id, registered_primary_sd = as.numeric(primary_sd),
              registered_alternative_sd = as.numeric(alternative_sd),
              candidate_order = as.integer(candidate_order))
  if (!nrow(r)) stop("No frozen numeric alternative SD rows supplied")
  if (anyDuplicated(r$effect_id)) stop("A scenario may contain only one alternative SD per effect_id")
  if (length(setdiff(r$effect_id, d$effect_id))) stop("Alternative SD effect_id is absent from scenario input")
  z <- d %>% left_join(r, by = "effect_id")
  idx <- which(is.finite(z$registered_alternative_sd))
  if (!length(idx)) stop("Alternative SD rows failed to link")
  if (any(z$registered_primary_sd[idx] <= 0 | z$registered_alternative_sd[idx] <= 0))
    stop("Alternative SD values must be positive")
  ratio <- z$registered_primary_sd[idx] / z$registered_alternative_sd[idx]
  z$TE[idx] <- z$TE[idx] * ratio
  z$seTE[idx] <- z$seTE[idx] * ratio
  z$variance[idx] <- z$seTE[idx]^2
  z %>% select(all_of(names(d)))
}

# Rebuild every retained multi-arm study as a complete set of pairwise contrasts.
# When an ICC scenario changes marginal SEs, preserve the frozen S correlation
# structure by congruence scaling before deriving the non-reference contrasts.
complete_for_netmeta <- function(d) {
  block_ids <- unique(S_long$block_id)
  block_sets <- lapply(block_ids, function(b) sort(unique(S_long$row_contrast[S_long$block_id == b])))
  names(block_sets) <- block_ids
  out <- list()
  groups <- split(d, interaction(d$outcome, d$study_id, drop = TRUE, lex.order = TRUE))
  for (nm in names(groups)) {
    g <- groups[[nm]]; g <- g[order(g$effect_id), , drop = FALSE]
    if (nrow(g) == 1L) { out[[length(out) + 1L]] <- g; next }
    target <- sort(g$effect_id)
    candidate <- names(block_sets)[vapply(block_sets, identical, logical(1), target)]
    if (length(candidate) != 1L) stop("Cannot identify complete covariance block for ", nm)
    so <- matrix_from_long(S_long, candidate[[1]])
    ord <- match(so$labels, g$effect_id); if (anyNA(ord)) stop("Covariance labels mismatch for ", nm)
    g <- g[ord, , drop = FALSE]
    scale <- sqrt(g$variance / diag(so$M)); S <- diag(scale) %*% so$M %*% diag(scale)
    out[[length(out) + 1L]] <- g
    if (nrow(g) > 1L) for (i in seq_len(nrow(g) - 1L)) for (j in (i + 1L):nrow(g)) {
      z <- g[i, , drop = FALSE]
      z$effect_id <- paste0(candidate[[1]], "_SENS_DERIVED_", g$treat1_arm_id[i], "_vs_", g$treat1_arm_id[j])
      z$comparison_id <- paste0("derived_", g$treat1_arm_id[i], "_vs_", g$treat1_arm_id[j])
      z$treat1_arm_id <- g$treat1_arm_id[i]; z$treat2_arm_id <- g$treat1_arm_id[j]
      z$treat1_node <- g$treat1_node[i]; z$treat2_node <- g$treat1_node[j]
      z$TE <- g$TE[i] - g$TE[j]; z$variance <- S[i, i] + S[j, j] - 2 * S[i, j]
      z$seTE <- sqrt(z$variance); z$derived_comparison <- "yes"
      out[[length(out) + 1L]] <- z
    }
  }
  bind_rows(out)
}

high <- rob %>% mutate(outcome = unname(rob_code[outcome_code])) %>%
  filter(rob_overall == "High", !is.na(outcome)) %>% distinct(study_id, outcome)

objective_pa_studies <- links %>% filter(outcome_code == "PA", analysis_status == "primary") %>%
  group_by(study_id) %>% summarise(objective = all(grepl("^objective", measurement_type)), .groups = "drop") %>%
  filter(objective) %>% pull(study_id)

study29 <- effects_all_source %>% filter(study_id == "29", analysis_status == "sensitivity", outcome == "身体活动")
if (nrow(study29) == 1L) {
  study29$outcome <- "PA"
  node_lookup <- setNames(arm_map$approved_node, arm_map$arm_id)
  study29$treat1_node <- unname(node_lookup[study29$treat1_arm_id])
  study29$treat2_node <- unname(node_lookup[study29$treat2_arm_id])
  study29$analysis_unit <- "SMD"
  study29 <- study29[, intersect(names(primary), names(study29)), drop = FALSE]
  for (nm in setdiff(names(primary), names(study29))) study29[[nm]] <- NA
  study29 <- study29[, names(primary), drop = FALSE]
}

scenario_rows <- list()
add_scenario <- function(id, outcome, data, rule, parameter = "", source = "v3.1 section 13.1") {
  scenario_rows[[length(scenario_rows) + 1L]] <<- list(id = id, outcome = outcome, data = data,
                                                       rule = rule, parameter = parameter, source = source)
}

for (o in outcomes) {
  d <- primary[primary$outcome == o, , drop = FALSE]
  hids <- high$study_id[high$outcome == o]
  add_scenario("S01_EXCLUDE_HIGH_ROB", o, d[!d$study_id %in% hids, , drop = FALSE],
               "Exclude studies rated High for the analysed outcome", paste(hids, collapse = ";"))
  add_scenario("S02_EXTERNAL_ICC_LOW", o, make_icc_scenario(d, .01),
               "Set every externally sourced ICC to a common lower scenario", "ICC=0.01")
  add_scenario("S03_EXTERNAL_ICC_HIGH", o, make_icc_scenario(d, .10),
               "Set every externally sourced ICC to a common upper scenario", "ICC=0.10")
  ext_icc_ids <- unique(d$study_id[grepl("EXTERNAL_ICC", d$sensitivity_group)])
  add_scenario("S04_EXCLUDE_EXTERNAL_ICC", o, d[!d$study_id %in% ext_icc_ids, , drop = FALSE],
               "Exclude all studies using an external ICC", paste(ext_icc_ids, collapse = ";"))
}

for (o in c("PA", "SB")) {
  d <- primary[primary$outcome == o, , drop = FALSE]
  ids <- unique(d$study_id[grepl("EXTERNAL_SD|BASELINE_SD_PROXY", d$sensitivity_group)])
  add_scenario("S05_EXCLUDE_EXTERNAL_OR_PROXY_SD", o, d[!d$study_id %in% ids, , drop = FALSE],
               "Exclude all studies using an external or proxy SD", paste(ids, collapse = ";"))
  add_scenario("S06_EXCLUDE_STUDY11_PERCENTAGE", o, d[d$study_id != "11", , drop = FALSE],
               "Exclude Study 11 percentage-scale outcome", "study_id=11")
}

dpa <- primary[primary$outcome == "PA", , drop = FALSE]
if (nrow(study29) == 1L) add_scenario("S07_INCLUDE_STUDY29_PA", "PA", bind_rows(dpa, study29),
                                      "Add the locked conservative-SE Study 29 PA result", "study_id=29")
add_scenario("S08_PA_OBJECTIVE_ONLY", "PA", dpa[dpa$study_id %in% objective_pa_studies, , drop = FALSE],
             "Restrict to studies whose selected PA result is device measured", paste(objective_pa_studies, collapse = ";"))

dsc <- primary[primary$outcome == "Screen", , drop = FALSE]
narrow_ids <- unique(dsc$study_id[grepl("NARROW_SCREEN_BEHAVIOR", dsc$sensitivity_group)])
add_scenario("S09_EXCLUDE_NARROW_SCREEN", "Screen", dsc[!dsc$study_id %in% narrow_ids, , drop = FALSE],
             "Exclude the prespecified narrow screen-construct group", paste(narrow_ids, collapse = ";"))

# Registered alternative-SD sensitivity analyses. The combined scenario uses
# the first-listed, highest-priority alternative for every eligible effect.
# Candidate-specific scenarios change one effect at a time so that no
# arbitrary cross-study combination or percentage perturbation is introduced.
sd_available <- sd_registry %>%
  filter(availability == "FROZEN_NUMERIC") %>%
  mutate(primary_sd = as.numeric(primary_sd), alternative_sd = as.numeric(alternative_sd),
         candidate_order = as.integer(candidate_order))

sd_qa <- sd_available %>%
  left_join(primary %>% select(effect_id, primary_TE = TE, primary_seTE = seTE), by = "effect_id") %>%
  mutate(scale_ratio = primary_sd / alternative_sd,
         alternative_TE = primary_TE * scale_ratio,
         alternative_seTE = primary_seTE * scale_ratio,
         transformation_valid = is.finite(alternative_TE) & is.finite(alternative_seTE) &
           primary_sd > 0 & alternative_sd > 0 & alternative_seTE > 0)
if (nrow(sd_qa) != nrow(sd_available) || !all(sd_qa$transformation_valid))
  stop("Alternative SD registry failed transformation QA")
write_csv8(sd_qa, file.path(sensitivity_dir, "alternative_SD_input_QA.csv"))

sd_coverage <- sd_registry %>%
  group_by(effect_id, study_id, outcome, primary_sd) %>%
  summarise(n_frozen_alternatives = sum(availability == "FROZEN_NUMERIC"),
            coverage_status = ifelse(n_frozen_alternatives > 0,
                                     "NUMERIC_ALTERNATIVE_AVAILABLE",
                                     "NO_NUMERIC_ALTERNATIVE_RETAIN_EXCLUSION_CHECK"),
            .groups = "drop")
write_csv8(sd_coverage, file.path(sensitivity_dir, "alternative_SD_coverage.csv"))

for (o in c("PA", "SB")) {
  d <- primary[primary$outcome == o, , drop = FALSE]
  first_alt <- sd_available %>% filter(outcome == o, candidate_order == 1L)
  add_scenario("S10A_ALT_SD_COMBINED_FIRST", o, make_alternative_sd_scenario(d, first_alt),
               "Replace every eligible external SD with its first-listed frozen alternative",
               paste0(first_alt$study_id, ":", first_alt$primary_sd, "->", first_alt$alternative_sd, collapse = ";"),
               "Pre-recorded study-level evidence files")
}

for (i in seq_len(nrow(sd_available))) {
  r <- sd_available[i, , drop = FALSE]
  o <- r$outcome[[1]]; d <- primary[primary$outcome == o, , drop = FALSE]
  id <- paste0("S10B_ALT_SD_", o, "_STUDY", r$study_id[[1]], "_C", r$candidate_order[[1]])
  add_scenario(id, o, make_alternative_sd_scenario(d, r),
               "Replace one effect with one frozen candidate SD",
               paste0("study=", r$study_id[[1]], ";effect=", r$effect_id[[1]],
                      ";SD=", r$primary_sd[[1]], "->", r$alternative_sd[[1]],
                      ";role=", r$alternative_role[[1]]),
               r$source_record[[1]])
}

primary_effects <- read_csv(file.path(standard_dir, "effects", "network_effects_vs_UCWL.csv"), show_col_types = FALSE)
sens_status <- sens_effects <- list()
for (s in scenario_rows) {
  d <- s$data; nodes <- sort(unique(c(d$treat1_node, d$treat2_node)))
  connected <- nrow(d) > 0 && is_connected(d)
  ref_present <- reference_node %in% nodes
  if (!connected || !ref_present || length(nodes) < 2L) {
    sens_status[[length(sens_status) + 1L]] <- data.frame(
      sensitivity_id = s$id, outcome = s$outcome, status = "NOT_RUN_DISCONNECTED_OR_REFERENCE_ABSENT",
      rule = s$rule, parameter_or_studies = s$parameter, rows = nrow(d), studies = n_distinct(d$study_id),
      nodes = length(nodes), connected = connected, reference_present = ref_present,
      tau2 = NA_real_, I2 = NA_real_, warnings = "", stringsAsFactors = FALSE)
    next
  }
  dc <- try(complete_for_netmeta(d), silent = TRUE)
  if (inherits(dc, "try-error")) {
    fit_run <- dc
  } else {
    fit_run <- try(fit_netmeta(dc), silent = TRUE)
  }
  if (inherits(fit_run, "try-error")) {
    sens_status[[length(sens_status) + 1L]] <- data.frame(
      sensitivity_id = s$id, outcome = s$outcome, status = "FIT_FAILED", rule = s$rule,
      parameter_or_studies = s$parameter, rows = nrow(d), studies = n_distinct(d$study_id), nodes = length(nodes),
      connected = connected, reference_present = ref_present, tau2 = NA_real_, I2 = NA_real_,
      warnings = as.character(fit_run), stringsAsFactors = FALSE)
    next
  }
  fit <- fit_run$value
  saveRDS(list(model = fit, input_observed = d, input_complete = dc, warnings = fit_run$warnings, rule = s$rule, parameter = s$parameter),
          file.path(sensitivity_dir, "models", paste0(s$id, "_", s$outcome, ".rds")))
  sens_status[[length(sens_status) + 1L]] <- data.frame(
    sensitivity_id = s$id, outcome = s$outcome, status = "SUCCESS", rule = s$rule,
    parameter_or_studies = s$parameter, rows = nrow(d), studies = fit$k, nodes = length(fit$trts),
    connected = TRUE, reference_present = TRUE, tau2 = fit$tau^2, I2 = fit$I2,
    warnings = paste(fit_run$warnings, collapse = " | "), stringsAsFactors = FALSE)
  e <- extract_ref_effects(fit, s$outcome, s$id) %>%
    left_join(primary_effects %>% select(outcome, treatment, primary_TE = TE, primary_lower = lower, primary_upper = upper),
              by = c("outcome", "treatment")) %>%
    mutate(absolute_change = abs(TE - primary_TE), direction_changed = sign(TE) != sign(primary_TE))
  sens_effects[[length(sens_effects) + 1L]] <- e
}

sens_status_df <- bind_rows(sens_status)
write_csv8(sens_status_df, file.path(sensitivity_dir, "sensitivity_model_status.csv"))
sens_effects_df <- bind_rows(sens_effects)
write_csv8(sens_effects_df, file.path(sensitivity_dir, "sensitivity_effects_vs_UCWL.csv"))
alternative_sd_summary <- sens_effects_df %>%
  filter(grepl("^S10", analysis_id)) %>%
  group_by(outcome, treatment) %>%
  summarise(
    scenarios = n(), min_TE = min(TE), max_TE = max(TE),
    min_lower = min(lower), max_upper = max(upper),
    direction_flips = sum(direction_changed),
    significant_scenarios = sum(lower > 0 | upper < 0),
    all_scenarios_same_direction = all(sign(TE) == sign(primary_TE)),
    .groups = "drop")
write_csv8(alternative_sd_summary, file.path(sensitivity_dir, "alternative_SD_sensitivity_summary.csv"))

# Prespecified single-covariate network meta-regression of intervention duration for PA and SB.
reg_status <- reg_coef <- reg_inputs <- list()
node_codes <- c(
  "Usual care/waitlist" = "UCWL", "Minimal education" = "ME", "Health education" = "HE",
  "Behavioural intervention" = "BI", "Physical activity intervention" = "PAI",
  "Environmental intervention" = "ENV", "Physical activity + health education" = "PAHE",
  "Integrated multicomponent intervention" = "IMC")
for (o in c("PA", "SB")) {
  d <- model_complete[model_complete$outcome == o, , drop = FALSE] %>%
    left_join(characteristics %>% select(study_id, intervention_duration_weeks, duration_evidence_status), by = "study_id")
  d$intervention_duration_weeks <- as.numeric(d$intervention_duration_weeks)
  d <- d[is.finite(d$intervention_duration_weeks) & d$intervention_duration_weeks > 0, , drop = FALSE]
  study_values <- d %>% distinct(study_id, intervention_duration_weeks)
  center <- median(log2(study_values$intervention_duration_weeks))
  d$log2_duration_centered <- log2(d$intervention_duration_weeks) - center
  d$treat1_node_full <- d$treat1_node; d$treat2_node_full <- d$treat2_node
  d$treat1_node <- unname(node_codes[d$treat1_node]); d$treat2_node <- unname(node_codes[d$treat2_node])
  if (anyNA(d$treat1_node) || anyNA(d$treat2_node)) stop("Node abbreviation failed for ", o)
  base_run <- fit_netmeta(d, reference = "UCWL")
  base <- base_run$value
  cov_map <- setNames(d$log2_duration_centered[!duplicated(d$study_id)], d$study_id[!duplicated(d$study_id)])
  covar_vector <- unname(cov_map[base$data$.studlab])
  if (anyNA(covar_vector)) stop("Duration mapping failed for ", o)
  reg_run <- capture_warning(netmetareg(base, covar = covar_vector, consistency = TRUE,
                                        assumption = "common", method.tau = "REML"))
  reg <- reg_run$value; br <- reg$results[reg$results$type == "beta", , drop = FALSE]
  if (nrow(br) != 1L) stop("Expected one duration coefficient for ", o)
  saveRDS(list(base = base, regression = reg, input = d, center_log2 = center),
          file.path(regression_dir, "models", paste0(o, "_duration_NMR_REML.rds")))
  reg_status[[o]] <- data.frame(
    outcome = o, status = "SUCCESS", studies = n_distinct(d$study_id), rows = nrow(d), nodes = length(base$trts),
    missing_duration_studies = paste(setdiff(unique(model_complete$study_id[model_complete$outcome == o]), unique(d$study_id)), collapse = ";"),
    center_log2_weeks = center, center_weeks = 2^center, baseline_tau2 = base$tau^2,
    residual_tau2 = reg$tau2, optimizer_convergence = ifelse(is.null(reg$opt.res$convergence), NA, reg$opt.res$convergence),
    warnings = paste(c(base_run$warnings, reg_run$warnings), collapse = " | "), stringsAsFactors = FALSE)
  reg_coef[[o]] <- data.frame(
    outcome = o, covariate = "log2_intervention_duration_weeks_centered",
    interpretation_unit = "per doubling of intervention duration", beta = br$coef, se = br$se,
    lower = br$lower, upper = br$upper, z = br$z, p_value = br$pval,
    interpretation_scope = "study-level association; not a causal dose-response", stringsAsFactors = FALSE)
  reg_inputs[[o]] <- d %>% select(outcome, study_id, effect_id, treat1_node, treat2_node, TE, seTE,
                                  intervention_duration_weeks, log2_duration_centered, duration_evidence_status)
}
write_csv8(bind_rows(reg_status), file.path(regression_dir, "duration_NMR_model_status.csv"))
write_csv8(bind_rows(reg_coef), file.path(regression_dir, "duration_NMR_coefficients.csv"))
write_csv8(bind_rows(reg_inputs), file.path(regression_dir, "duration_NMR_input.csv"))

cat("SENSITIVITY_AND_DURATION_NMR_COMPLETE\n")
print(sens_status_df %>% count(status))
print(bind_rows(reg_coef))
