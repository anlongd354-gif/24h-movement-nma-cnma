# Code/package preflight. Does not fit or change any model.
args0 <- commandArgs(trailingOnly = FALSE)
file0 <- sub("^--file=", "", args0[grepl("^--file=", args0)])
root <- if (length(file0)) dirname(normalizePath(file0[[1]], winslash = "/")) else normalizePath(getwd(), winslash = "/")
files <- list.files(root, pattern = "[.]R$", recursive = TRUE, full.names = TRUE)
if (!length(files)) stop("No R files found. Check the repository path and your system locale.")
for (f in files) parse(file = f, encoding = "UTF-8")
cat("R_SYNTAX_PASS:", length(files), "files\n")
packages <- c("readr", "dplyr", "tidyr", "ggplot2", "netmeta", "Matrix", "jsonlite", "digest", "metafor")
available <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
if (any(!available)) stop("Install missing R packages: ", paste(packages[!available], collapse = ", "))
for (p in packages) cat(p, as.character(packageVersion(p)), "\n")
schema <- jsonlite::fromJSON(file.path(root, "docs", "input_schema.json"))
missing <- schema$files$path[!file.exists(file.path(root, schema$files$path))]
if (length(missing)) {
  cat("Actual analysis data are not included in this code release. Missing input files:\n")
  cat(paste0("  ", missing, collapse = "\n"), "\n")
  cat("See docs/INPUT_FORMATS.md and the header-only input_templates/ directory.\n")
  if ("--require-data" %in% commandArgs(trailingOnly = TRUE)) stop("Provide populated input data before fitting models.")
} else {
  cat("INPUT_FILES_PRESENT; dataset content is checked by the analysis scripts.\n")
}
cat("CODE_PREFLIGHT_PASS (syntax and installed dependencies only)\n")
