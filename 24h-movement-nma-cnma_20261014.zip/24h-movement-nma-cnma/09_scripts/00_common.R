options(stringsAsFactors = FALSE, encoding = "UTF-8", warn = 1, digits = 15)

# Use the normal R library paths; optionally configure R_LIBS_USER before starting R.

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(netmeta)
  library(Matrix)
  library(jsonlite)
  library(digest)
})

script_path <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", args[grepl("^--file=", args)])
  if (length(f)) normalizePath(f[[1]], winslash = "/", mustWork = TRUE) else normalizePath(getwd(), winslash = "/")
}

analysis_root <- normalizePath(Sys.getenv("NMA_ANALYSIS_ROOT", unset = file.path(dirname(script_path()), "..")), winslash = "/", mustWork = TRUE)
input_dir <- file.path(analysis_root, "01_inputs")
validation_dir <- file.path(analysis_root, "02_validation")
standard_dir <- file.path(analysis_root, "03_standard_nma")
sensitivity_dir <- file.path(analysis_root, "04_sensitivity")
regression_dir <- file.path(analysis_root, "05_meta_regression")
cnma_dir <- file.path(analysis_root, "06_cnma")
cinema_dir <- file.path(analysis_root, "07_cinema_pending")
figure_dir <- file.path(analysis_root, "08_figures")
report_dir <- file.path(analysis_root, "10_reports")
for (d in c(validation_dir, standard_dir, sensitivity_dir, regression_dir, cnma_dir,
            cinema_dir, figure_dir, report_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

outcomes <- c("PA", "SB", "Screen", "Sleep")
outcome_labels <- c(PA = "Physical activity", SB = "Sedentary behaviour",
                    Screen = "Screen time", Sleep = "Sleep duration")
reference_node <- "Usual care/waitlist"

read_input <- function(name) {
  read_csv(file.path(input_dir, name), col_types = cols(study_id = col_character()),
           locale = locale(encoding = "UTF-8"), show_col_types = FALSE)
}

write_csv8 <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  write_excel_csv(as.data.frame(x), path, na = "")
}

capture_warning <- function(expr) {
  warns <- character()
  value <- withCallingHandlers(expr, warning = function(w) {
    warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning")
  })
  list(value = value, warnings = unique(warns))
}

matrix_from_long <- function(tbl, block_id) {
  z <- tbl[tbl$block_id == block_id, , drop = FALSE]
  if (!nrow(z)) stop("Missing covariance block: ", block_id)
  m <- max(z$row)
  M <- matrix(NA_real_, m, m)
  row_labels <- col_labels <- character(m)
  for (i in seq_len(nrow(z))) {
    M[z$row[i], z$column[i]] <- z$value[i]
    row_labels[z$row[i]] <- z$row_contrast[i]
    col_labels[z$column[i]] <- z$column_contrast[i]
  }
  if (any(!is.finite(M)) || !identical(row_labels, col_labels)) stop("Invalid covariance block: ", block_id)
  list(M = M, labels = row_labels)
}

graph_membership <- function(nodes, edge1, edge2) {
  nodes <- sort(unique(nodes))
  adj <- setNames(vector("list", length(nodes)), nodes)
  for (i in seq_along(edge1)) {
    a <- edge1[[i]]; b <- edge2[[i]]
    if (is.na(a) || is.na(b) || a == b) next
    adj[[a]] <- unique(c(adj[[a]], b)); adj[[b]] <- unique(c(adj[[b]], a))
  }
  membership <- setNames(rep(NA_integer_, length(nodes)), nodes)
  component <- 0L
  for (node in nodes) {
    if (!is.na(membership[[node]])) next
    component <- component + 1L; queue <- node
    while (length(queue)) {
      current <- queue[[1]]; queue <- queue[-1]
      if (!is.na(membership[[current]])) next
      membership[[current]] <- component
      queue <- unique(c(queue, adj[[current]][is.na(membership[adj[[current]]])]))
    }
  }
  data.frame(node = names(membership), component = unname(membership),
             degree = vapply(adj, length, integer(1)), stringsAsFactors = FALSE)
}

is_connected <- function(d, t1 = "treat1_node", t2 = "treat2_node") {
  nodes <- unique(c(d[[t1]], d[[t2]]))
  if (!length(nodes)) return(FALSE)
  nrow(unique(graph_membership(nodes, d[[t1]], d[[t2]])["component"])) == 1L
}

fit_netmeta <- function(d, reference = reference_node, prediction = TRUE) {
  if (!nrow(d)) stop("No rows supplied to netmeta")
  if (!is_connected(d)) stop("Network is disconnected")
  sm <- unique(d$effect_measure); unit <- unique(d$analysis_unit)
  if (length(sm) != 1L || length(unit) != 1L) stop("Mixed scale or unit")
  capture_warning(netmeta(
    TE = TE, seTE = seTE, treat1 = treat1_node, treat2 = treat2_node,
    studlab = study_id, data = d, sm = sm[[1]], common = FALSE, random = TRUE,
    prediction = prediction, reference.group = reference, small.values = "bad",
    method.tau = "REML", details.chkmultiarm = TRUE, backtransf = FALSE, keepdata = TRUE
  ))
}

extract_ref_effects <- function(fit, outcome, analysis_id = "primary") {
  bind_rows(lapply(setdiff(fit$trts, fit$reference.group), function(trt) {
    te <- unname(fit$TE.random[trt, fit$reference.group]); se <- unname(fit$seTE.random[trt, fit$reference.group])
    data.frame(analysis_id = analysis_id, outcome = outcome, treatment = trt,
               reference = fit$reference.group, effect_measure = fit$sm,
               TE = te, seTE = se, lower = unname(fit$lower.random[trt, fit$reference.group]),
               upper = unname(fit$upper.random[trt, fit$reference.group]),
               p_value = 2 * pnorm(-abs(te / se)),
               prediction_lower = if (!is.null(fit$lower.predict)) unname(fit$lower.predict[trt, fit$reference.group]) else NA_real_,
               prediction_upper = if (!is.null(fit$upper.predict)) unname(fit$upper.predict[trt, fit$reference.group]) else NA_real_,
               direction = "positive_favours_treatment", stringsAsFactors = FALSE)
  }))
}

extract_all_effects <- function(fit, outcome, analysis_id = "primary") {
  bind_rows(lapply(combn(sort(fit$trts), 2, simplify = FALSE), function(pair) {
    a <- pair[[1]]; b <- pair[[2]]; te <- unname(fit$TE.random[a, b]); se <- unname(fit$seTE.random[a, b])
    data.frame(analysis_id = analysis_id, outcome = outcome, treatment1 = a, treatment2 = b,
               comparison = paste(a, b, sep = " vs "), effect_measure = fit$sm,
               TE = te, seTE = se, lower = unname(fit$lower.random[a, b]),
               upper = unname(fit$upper.random[a, b]), p_value = 2 * pnorm(-abs(te / se)),
               prediction_lower = if (!is.null(fit$lower.predict)) unname(fit$lower.predict[a, b]) else NA_real_,
               prediction_upper = if (!is.null(fit$upper.predict)) unname(fit$upper.predict[a, b]) else NA_real_,
               direction = "positive_favours_treatment1", stringsAsFactors = FALSE)
  }))
}

full_rank_basis <- function(X, tol = 1e-9) {
  if (!ncol(X)) return(list(Xb = matrix(numeric(), nrow(X), 0), rank = 0L, selected = integer()))
  q <- qr(X, tol = tol, LAPACK = FALSE); r <- q$rank
  selected <- if (r) q$pivot[seq_len(r)] else integer()
  list(Xb = X[, selected, drop = FALSE], rank = r, selected = selected)
}

profile_at_tau2 <- function(y, Xb, S, R, tau2) {
  V <- S + tau2 * R
  cv <- try(chol(V), silent = TRUE)
  if (inherits(cv, "try-error")) return(list(objective = Inf))
  Vi <- chol2inv(cv); logdetV <- 2 * sum(log(diag(cv)))
  if (ncol(Xb)) {
    A <- crossprod(Xb, Vi %*% Xb); ca <- try(chol(A), silent = TRUE)
    if (inherits(ca, "try-error")) return(list(objective = Inf))
    beta <- solve(A, crossprod(Xb, Vi %*% y)); cov <- solve(A)
    residual <- y - as.numeric(Xb %*% beta); logdetA <- 2 * sum(log(diag(ca)))
  } else {
    beta <- numeric(); cov <- matrix(numeric(), 0, 0); residual <- y; logdetA <- 0
  }
  Q <- as.numeric(crossprod(residual, Vi %*% residual)); df <- length(y) - ncol(Xb)
  list(objective = 0.5 * (logdetV + logdetA + Q + df * log(2 * pi)),
       beta = beta, cov = cov, residual = residual, Q = Q, V = V, Vi = Vi)
}

fit_reml <- function(y, X, S, R, tol = 1e-9) {
  basis <- full_rank_basis(X, tol); rank <- basis$rank; df <- length(y) - rank
  if (df <= 0) return(list(tau2 = NA_real_, tau = NA_real_, rank = rank, df = df,
                           selected = basis$selected, convergence = "not_assessable_df_le_0"))
  upper <- max(1, 20 * var(y), 5 * max(y^2), na.rm = TRUE)
  fn <- function(t) profile_at_tau2(y, basis$Xb, S, R, t)$objective
  opt <- optimize(fn, interval = c(0, upper), tol = 1e-10); f0 <- fn(0)
  tau2 <- if (is.finite(f0) && f0 <= opt$objective + 1e-8) 0 else opt$minimum
  final <- profile_at_tau2(y, basis$Xb, S, R, tau2)
  c(final, list(tau2 = tau2, tau = sqrt(tau2), rank = rank, df = df,
                selected = basis$selected, convergence = ifelse(is.finite(final$objective), "converged", "failed"),
                boundary = ifelse(tau2 <= 1e-12, "lower_0", "interior"), upper = upper))
}

fit_gls_fixed_v <- function(y, X, V, tol = 1e-9) {
  basis <- full_rank_basis(X, tol); Xb <- basis$Xb; Vi <- chol2inv(chol(V))
  if (!ncol(Xb)) return(list(Q = as.numeric(crossprod(y, Vi %*% y)), rank = 0L, beta = numeric(), cov = matrix(numeric(), 0, 0)))
  A <- crossprod(Xb, Vi %*% Xb); beta <- solve(A, crossprod(Xb, Vi %*% y)); cov <- solve(A)
  residual <- y - as.numeric(Xb %*% beta)
  list(Q = as.numeric(crossprod(residual, Vi %*% residual)), rank = basis$rank,
       beta = beta, cov = cov, selected = basis$selected)
}

weighted_condition_number <- function(X, V, tol = 1e-9) {
  b <- full_rank_basis(X, tol)
  if (!b$rank) return(NA_real_)
  Vi <- chol2inv(chol(V)); A <- crossprod(b$Xb, Vi %*% b$Xb)
  d <- sqrt(diag(A)); A <- diag(1/d) %*% A %*% diag(1/d)
  ev <- eigen(A, symmetric = TRUE, only.values = TRUE)$values
  ev <- ev[ev > tol * max(1, max(ev))]
  if (length(ev) < b$rank) Inf else sqrt(max(ev) / min(ev))
}

build_cnma_blocks <- function(d, X, S_long, R_long) {
  groups <- split(seq_len(nrow(d)), interaction(d$study_id, drop = TRUE, lex.order = TRUE))
  yl <- Xl <- Sl <- Rl <- ml <- list(); cursor <- 0L
  for (study in names(groups)) {
    idx <- groups[[study]]; g <- d[idx, , drop = FALSE]
    block_ids <- unique(g$covariance_block_id[!is.na(g$covariance_block_id) & g$covariance_block_id != ""])
    if (length(block_ids) > 1L) stop("Multiple covariance blocks in ", study)
    if (length(block_ids) == 1L) {
      so <- matrix_from_long(S_long, block_ids[[1]]); ro <- matrix_from_long(R_long, block_ids[[1]])
      ord <- match(so$labels, g$effect_id); if (anyNA(ord)) stop("Block labels mismatch: ", block_ids[[1]])
      g <- g[ord, , drop = FALSE]; idx <- idx[ord]; S <- so$M; R <- ro$M
    } else {
      if (nrow(g) != 1L) stop("Multiple rows without covariance block: ", study)
      S <- matrix(g$variance, 1, 1); R <- matrix(1, 1, 1)
    }
    if (min(eigen(S, symmetric = TRUE, only.values = TRUE)$values) <= 0) stop("S not positive definite: ", study)
    yl[[study]] <- as.numeric(g$TE); Xl[[study]] <- X[idx, , drop = FALSE]
    Sl[[study]] <- S; Rl[[study]] <- R
    ml[[study]] <- data.frame(study_id = study, effect_id = g$effect_id,
                              global_row = cursor + seq_len(nrow(g)), stringsAsFactors = FALSE)
    cursor <- cursor + nrow(g)
  }
  list(y = unlist(yl, use.names = FALSE), X = do.call(rbind, Xl),
       S = as.matrix(bdiag(Sl)), R = as.matrix(bdiag(Rl)),
       meta = bind_rows(ml), study_rows = split(seq_len(cursor), bind_rows(ml)$study_id))
}

component_signature <- function(A) apply(A, 1, paste0, collapse = "")

