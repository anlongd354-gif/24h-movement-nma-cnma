# 24-hour movement behaviour intervention analyses

R analysis code accompanying **Comparative Effects of Interventions on 24-Hour Movement Behaviours in Children and Adolescents: A Systematic Review with Network and Component Network Meta-Analyses**.

## What is provided

- Pairwise random-effects meta-analysis using `metafor`.
- Frequentist random-effects network meta-analysis using `netmeta`, with network diagnostics and P-scores.
- Sensitivity analyses and duration network meta-regression.
- Exploratory additive component network meta-analysis using the original generalised least-squares/profile-REML routines and exact multi-arm covariance inputs.
- Auxiliary PA small-study-effect and measurement-method network meta-regressions.
- Input-format documentation, machine-readable schemas and header-only CSV templates.

**Actual analysis input data are not included.** The templates contain no data rows. Running `verify_code.R` checks code syntax and installed dependencies; it does not reproduce the statistical results. Model execution requires the populated input files described in [INPUT_FORMATS.md](docs/INPUT_FORMATS.md).

This code release does not contain manuscript drafts, published-paper PDFs, author contribution drafts, participant-level data or model-result datasets. Final CINeMA/ROB-MEN judgements and publication artwork require their separate adjudication/production workflows; `04_finalize_package.R` creates preparation interfaces and pending templates rather than completed confidence judgements.

## Software

The original analyses used R 4.6.0, `netmeta` 3.6-1 and `metafor` 5.0-1. Locally verified package versions for this release are listed in [SOFTWARE_VERSIONS.csv](docs/SOFTWARE_VERSIONS.csv). Versions are recorded, not locked by an `renv` snapshot. Different package versions may affect numerical or graphical output.

Install the required packages in your normal R library:

```r
install.packages(c("readr", "dplyr", "tidyr", "ggplot2", "netmeta", "Matrix", "jsonlite", "digest", "metafor"))
```

From the repository root:

```sh
Rscript --vanilla verify_code.R
```

## Running analyses after obtaining the input data

Populate the paths specified in `docs/INPUT_FORMATS.md`. Files in `input_templates/` only illustrate the required headers; copying them without adding real data does not make a runnable dataset.

```sh
Rscript --vanilla verify_code.R --require-data
Rscript --vanilla pairwise/run_formal_pairwise_meta_analysis_20260923.R
Rscript --vanilla 09_scripts/99_run_all.R
Rscript --vanilla 09_scripts/05_verify_numeric_results.R
Rscript --vanilla 09_scripts/11_run_robmen_pa_small_study.R
Rscript --vanilla 09_scripts/13_run_pa_measurement_method_nmr.R
```

`99_run_all.R` runs scripts **01-04 only**, in that order. It does not run pairwise analyses, verification or the two auxiliary analyses. The original fixed row/model-count checks are specific to the manuscript dataset.

| Script | Main function |
| --- | --- |
| `09_scripts/00_common.R` | Shared packages, paths, network fitting and exact-covariance model functions |
| `09_scripts/01_run_standard_nma.R` | Four outcome-specific standard NMA models and diagnostics |
| `09_scripts/02_run_sensitivity_meta_regression.R` | Sensitivity analyses and duration meta-regressions |
| `09_scripts/03_run_cnma.R` | Taxonomic, function and implementation component models and diagnostics |
| `09_scripts/04_finalize_package.R` | Analysis summary, manifests and CINeMA/ROB-MEN preparation interfaces |
| `09_scripts/05_verify_numeric_results.R` | Original manuscript-specific numerical/input checks |
| `09_scripts/11_run_robmen_pa_small_study.R` | Auxiliary PA small-study-effect analyses |
| `09_scripts/13_run_pa_measurement_method_nmr.R` | Exploratory PA measurement-method meta-regression |
| `pairwise/run_formal_pairwise_meta_analysis_20260923.R` | Pairwise models, uncertainty safeguards, sensitivity and influence diagnostics |
| `verify_code.R` | Syntax/dependency preflight and input-file presence reporting |

By default, network-analysis scripts derive the project root from their location in `09_scripts/`; `NMA_ANALYSIS_ROOT` can point to another prepared analysis root. Pairwise analysis uses `pairwise/`, or `PAIRWISE_ANALYSIS_ROOT` when supplied. Use standard R libraries, or configure `R_LIBS_USER` for a custom package library.

Generated output directories include `02_validation/`, `03_standard_nma/`, `04_sensitivity/`, `05_meta_regression/`, `06_cnma/`, `07_cinema_pending/`, `08_figures/`, `10_reports/` and `pairwise/formal_model_run_20260923/`. They are not distributed as study data in this repository.

## Provenance and release verification

The release copies preserve the original analysis logic. Personal absolute paths and the Windows-only runner executable were replaced with portable equivalents. The legacy fixed sensitivity-model count was corrected to account for the existing optional S07 branch; see [SOURCE_PROVENANCE.json](docs/SOURCE_PROVENANCE.json) and [PORTABILITY_CHANGES.md](docs/PORTABILITY_CHANGES.md). Original project files were not edited.

See [VERIFICATION.md](docs/VERIFICATION.md) for the precise checks performed. The public code-only repository is insufficient to reproduce results without the actual input data.

## Manuscript code availability

The R code used for the statistical analyses, together with input-format documentation, is publicly available at https://github.com/anlongd354-gif/24h-movement-nma-cnma.
